# Constellar (nome provisório) — fase 3

Mod para Minecraft 1.21.1 / NeoForge 21.1.x.

## Energia
Agora é **FE normal** (compatível com cabos e máquinas de outros mods, como no ATM10).

## Progressão
1. **Telescópio** (bloco 3D): clique direito à noite, ao ar livre, para ler as estrelas.
   Cada leitura descobre uma constelação, que passa a aparecer desenhada no céu da noite.
2. **Forja Estelar** (multibloco 5x5 com torres):
   - centro: Forja Estelar; em cima dela: **Cristal do Void**
   - no mesmo nível da forja: 20 **Pedras Estelares** completando o 5x5
   - nos 4 cantos: torre de 3 **Pilares Estelares** com uma **Lente Estelar** no topo
   - clique com a **Varinha Estelar** na forja (ou no cristal) para formar a estrutura
3. Com a forja ativa: clique com itens (1 por clique, até 6) e depois com a Varinha para fazer a receita.
   Mão vazia na forja devolve o último item. As receitas pedem energia (FE) e, nos tomos, uma constelação descoberta.
   As lentes das torres captam luz das estrelas à noite e carregam a forja sozinhas
   (também aceita FE de cabos).
4. **Tomos de magia** (botão direito; gastam durabilidade e têm recarga):
   - Estrela Cadente (Órion): raio mágico que causa dano
   - Salto Estelar (Cruzeiro do Sul): impulso para frente
   - Cura Estelar (Lira): recupera vida

## Receitas da Forja (datapack)
`data/constellar/constellar/forge_recipe/*.json` — dá para criar outras só adicionando arquivos.

## Compilar
Use o GitHub Actions. O .jar sai em `build/libs/constellar-0.3.0.jar`.
