package com.example.constellar.spell;

import com.example.constellar.Constellar;
import net.minecraft.resources.ResourceLocation;

/** Magias dos Tomos. Cada uma exige que o jogador ja conheca uma constelacao. */
public enum Spell {
    FALLING_STAR("orion", 40),
    STELLAR_LEAP("crux", 20),
    STARLIGHT_HEAL("lyra", 120);

    private final ResourceLocation constellation;
    private final int cooldown;

    Spell(String constellationPath, int cooldown) {
        this.constellation = ResourceLocation.fromNamespaceAndPath(Constellar.MODID, constellationPath);
        this.cooldown = cooldown;
    }

    public ResourceLocation constellation() {
        return constellation;
    }

    public int cooldown() {
        return cooldown;
    }
}
