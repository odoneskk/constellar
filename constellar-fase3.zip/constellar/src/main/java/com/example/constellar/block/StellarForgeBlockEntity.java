package com.example.constellar.block;

import com.example.constellar.energy.FEStorage;
import com.example.constellar.forge.ForgeRecipe;
import com.example.constellar.forge.ForgeRecipeRegistry;
import com.example.constellar.multiblock.ForgeStructure;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.registry.ModBlockEntities;
import com.example.constellar.util.Starlight;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import java.util.ArrayList;
import java.util.List;

public class StellarForgeBlockEntity extends BlockEntity {
    public static final int SLOTS = 6;
    private static final int CHARGE_PER_TOWER = 10; // FE por tick, por torre com ceu aberto

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private final FEStorage energy = new FEStorage(100_000, 5_000, 0, this::setChanged);
    private float multiplier = 1.0f;

    public StellarForgeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STELLAR_FORGE.get(), pos, state);
    }

    public IEnergyStorage getEnergy() {
        return energy;
    }

    // ---------- itens na forja ----------
    public List<ItemStack> contents() {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack s : items) if (!s.isEmpty()) list.add(s);
        return list;
    }

    public boolean addItem(ItemStack single) {
        for (int i = 0; i < SLOTS; i++) {
            if (items.get(i).isEmpty()) {
                items.set(i, single);
                itemsChanged();
                return true;
            }
        }
        return false;
    }

    public ItemStack removeLast() {
        for (int i = SLOTS - 1; i >= 0; i--) {
            if (!items.get(i).isEmpty()) {
                ItemStack out = items.get(i);
                items.set(i, ItemStack.EMPTY);
                itemsChanged();
                return out;
            }
        }
        return ItemStack.EMPTY;
    }

    public void dropContents() {
        if (level == null) return;
        for (ItemStack s : items) {
            if (!s.isEmpty()) Block.popResource(level, worldPosition, s);
        }
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
    }

    private void itemsChanged() {
        setChanged();
        if (level != null) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
        }
    }

    // ---------- ativar (varinha) ----------
    public void activate(Player player) {
        if (!(level instanceof ServerLevel server)) return;
        BlockState state = getBlockState();
        boolean formed = state.getValue(StellarForgeBlock.FORMED);

        ForgeStructure.Mismatch mismatch = ForgeStructure.findMismatch(server, worldPosition);
        if (mismatch != null) {
            if (formed) server.setBlock(worldPosition, state.setValue(StellarForgeBlock.FORMED, false), 3);
            player.displayClientMessage(Component.translatable("message.constellar.forge_missing",
                    mismatch.expected().getName(),
                    mismatch.pos().getX(), mismatch.pos().getY(), mismatch.pos().getZ()), true);
            return;
        }

        if (!formed) {
            server.setBlock(worldPosition, state.setValue(StellarForgeBlock.FORMED, true), 3);
            server.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);
            burst(server, 60);
            for (int dx = -2; dx <= 2; dx += 4) {
                for (int dz = -2; dz <= 2; dz += 4) {
                    BlockPos top = worldPosition.offset(dx, 4, dz);
                    server.sendParticles(ParticleTypes.END_ROD, top.getX() + 0.5, top.getY() + 0.2, top.getZ() + 0.5,
                            12, 0.2, 0.3, 0.2, 0.02);
                }
            }
            player.displayClientMessage(Component.translatable("message.constellar.forge_formed"), true);
            return;
        }

        tryCraft(server, player);
    }

    private void tryCraft(ServerLevel server, Player player) {
        List<ItemStack> contents = contents();
        Registry<ForgeRecipe> registry = server.registryAccess().registryOrThrow(ForgeRecipeRegistry.KEY);

        for (ForgeRecipe recipe : registry) {
            if (!recipe.matches(contents)) continue;

            if (recipe.constellation().isPresent()
                    && !player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS).contains(recipe.constellation().get())) {
                player.displayClientMessage(Component.translatable("message.constellar.forge_need_constellation",
                        Starlight.constellationName(server, recipe.constellation().get())), true);
                return;
            }
            if (energy.getEnergyStored() < recipe.energy()) {
                player.displayClientMessage(Component.translatable("message.constellar.forge_need_energy",
                        energy.getEnergyStored(), recipe.energy()), true);
                return;
            }

            energy.consume(recipe.energy());
            for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
            itemsChanged();

            ItemEntity drop = new ItemEntity(server,
                    worldPosition.getX() + 0.5, worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5,
                    new ItemStack(recipe.result(), recipe.count()));
            drop.setDeltaMovement(0, 0.15, 0);
            server.addFreshEntity(drop);

            server.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.5F, 0.8F);
            server.playSound(null, worldPosition, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            burst(server, 40);
            player.displayClientMessage(Component.translatable("message.constellar.forge_crafted"), true);
            return;
        }
        player.displayClientMessage(Component.translatable("message.constellar.forge_no_recipe"), true);
    }

    private void burst(ServerLevel server, int count) {
        server.sendParticles(ParticleTypes.ENCHANT,
                worldPosition.getX() + 0.5, worldPosition.getY() + 1.3, worldPosition.getZ() + 0.5,
                count, 0.6, 0.6, 0.6, 0.4);
        server.sendParticles(ParticleTypes.END_ROD,
                worldPosition.getX() + 0.5, worldPosition.getY() + 1.3, worldPosition.getZ() + 0.5,
                count / 2, 0.4, 0.5, 0.4, 0.05);
    }

    // ---------- tick: as lentes das torres captam luz das estrelas ----------
    public static void serverTick(Level level, BlockPos pos, BlockState state, StellarForgeBlockEntity be) {
        boolean formed = state.getValue(StellarForgeBlock.FORMED);

        if (level.getGameTime() % 20 == 0) {
            be.multiplier = Starlight.computeMultiplier(level);
            if (formed && ForgeStructure.findMismatch(level, pos) != null) {
                level.setBlock(pos, state.setValue(StellarForgeBlock.FORMED, false), 3);
                formed = false;
            }
            be.setChanged();
        }

        if (formed && level.dimensionType().hasSkyLight() && Starlight.isNight(level)) {
            int towers = ForgeStructure.countTowersWithSky(level, pos);
            if (towers > 0) {
                be.energy.generate(Math.round(CHARGE_PER_TOWER * towers * be.multiplier));
            }
        }
    }

    // ---------- save / sync ----------
    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, items, registries);
        energy.save(tag);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items, registries);
        energy.load(tag);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
