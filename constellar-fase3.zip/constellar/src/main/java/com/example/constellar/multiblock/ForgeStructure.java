package com.example.constellar.multiblock;

import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;

/**
 * Forja Estelar (multibloco 5x5 com torres):
 *  - centro: Forja Estelar; em cima dela: Cristal do Void
 *  - no mesmo nivel da forja: os outros 20 blocos do 5x5 sao Pedra Estelar
 *  - nos 4 cantos: torres de 3 Pilares, com uma Lente Estelar no topo
 */
public final class ForgeStructure {
    private ForgeStructure() {}

    public record Mismatch(BlockPos pos, Block expected) {}

    @Nullable
    public static Mismatch findMismatch(Level level, BlockPos forge) {
        BlockPos crystal = forge.above();
        if (!level.getBlockState(crystal).is(ModBlocks.VOID_CRYSTAL.get())) {
            return new Mismatch(crystal, ModBlocks.VOID_CRYSTAL.get());
        }
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                boolean corner = Math.abs(dx) == 2 && Math.abs(dz) == 2;
                if (corner) {
                    for (int dy = 0; dy <= 2; dy++) {
                        BlockPos pos = forge.offset(dx, dy, dz);
                        if (!level.getBlockState(pos).is(ModBlocks.STELLAR_PILLAR.get())) {
                            return new Mismatch(pos, ModBlocks.STELLAR_PILLAR.get());
                        }
                    }
                    BlockPos top = forge.offset(dx, 3, dz);
                    if (!level.getBlockState(top).is(ModBlocks.STELLAR_LENS.get())) {
                        return new Mismatch(top, ModBlocks.STELLAR_LENS.get());
                    }
                } else {
                    BlockPos pos = forge.offset(dx, 0, dz);
                    if (!level.getBlockState(pos).is(ModBlocks.STELLAR_STONE.get())) {
                        return new Mismatch(pos, ModBlocks.STELLAR_STONE.get());
                    }
                }
            }
        }
        return null;
    }

    /** Quantas torres tem ceu aberto acima da lente (0 a 4). */
    public static int countTowersWithSky(Level level, BlockPos forge) {
        int count = 0;
        for (int dx = -2; dx <= 2; dx += 4) {
            for (int dz = -2; dz <= 2; dz += 4) {
                if (level.canSeeSky(forge.offset(dx, 4, dz))) count++;
            }
        }
        return count;
    }
}
