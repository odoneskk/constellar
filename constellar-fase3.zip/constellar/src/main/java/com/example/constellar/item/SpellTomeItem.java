package com.example.constellar.item;

import com.example.constellar.registry.ModAttachments;
import com.example.constellar.spell.Spell;
import com.example.constellar.util.Starlight;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.projectile.ProjectileUtil;

/** Tomo de magia: botao direito lanca a magia. Gasta durabilidade e tem tempo de recarga. */
public class SpellTomeItem extends Item {
    private static final double RANGE = 28.0;
    private final Spell spell;

    public SpellTomeItem(Properties properties, Spell spell) {
        super(properties);
        this.spell = spell;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel server)) {
            return InteractionResultHolder.sidedSuccess(stack, true);
        }

        if (!player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS).contains(spell.constellation())) {
            player.displayClientMessage(Component.translatable("message.constellar.spell_locked",
                    Starlight.constellationName(server, spell.constellation())), true);
            return InteractionResultHolder.fail(stack);
        }

        switch (spell) {
            case FALLING_STAR -> castFallingStar(server, player);
            case STELLAR_LEAP -> castLeap(server, player);
            case STARLIGHT_HEAL -> castHeal(server, player);
        }

        stack.hurtAndBreak(1, player, LivingEntity.getSlotForHand(hand));
        player.getCooldowns().addCooldown(this, spell.cooldown());
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    private void castFallingStar(ServerLevel server, Player player) {
        Vec3 start = player.getEyePosition();
        Vec3 look = player.getLookAngle();
        Vec3 end = start.add(look.scale(RANGE));

        BlockHitResult blockHit = server.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        if (blockHit.getType() != HitResult.Type.MISS) {
            end = blockHit.getLocation();
        }

        AABB box = player.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(player, start, end, box,
                e -> e instanceof LivingEntity && !e.isSpectator() && e.isPickable(), RANGE * RANGE);
        if (entityHit != null) {
            end = entityHit.getLocation();
            entityHit.getEntity().hurt(server.damageSources().magic(), 10.0F);
        }

        Vec3 path = end.subtract(start);
        double length = path.length();
        Vec3 dir = path.normalize();
        for (double d = 0.8; d < length; d += 0.6) {
            Vec3 p = start.add(dir.scale(d));
            server.sendParticles(ParticleTypes.END_ROD, p.x, p.y, p.z, 1, 0.02, 0.02, 0.02, 0.0);
        }
        server.sendParticles(ParticleTypes.FIREWORK, end.x, end.y, end.z, 20, 0.3, 0.3, 0.3, 0.1);
        server.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1.2F, 1.4F);
    }

    private void castLeap(ServerLevel server, Player player) {
        Vec3 look = player.getLookAngle();
        player.setDeltaMovement(look.x * 1.4, Math.max(look.y * 1.4, 0.0) + 0.5, look.z * 1.4);
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        server.sendParticles(ParticleTypes.CLOUD, player.getX(), player.getY(), player.getZ(), 25, 0.3, 0.1, 0.3, 0.05);
        server.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY(), player.getZ(), 15, 0.3, 0.2, 0.3, 0.1);
        server.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_FLAP, SoundSource.PLAYERS, 1.0F, 1.6F);
    }

    private void castHeal(ServerLevel server, Player player) {
        player.heal(8.0F);
        server.sendParticles(ParticleTypes.HAPPY_VILLAGER, player.getX(), player.getY() + 1.0, player.getZ(),
                25, 0.5, 0.8, 0.5, 0.0);
        server.sendParticles(ParticleTypes.END_ROD, player.getX(), player.getY() + 1.0, player.getZ(),
                15, 0.4, 0.8, 0.4, 0.05);
        server.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5F, 1.2F);
    }
}
