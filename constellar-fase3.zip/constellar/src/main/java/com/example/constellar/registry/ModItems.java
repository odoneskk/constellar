package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.example.constellar.item.EnergyReaderItem;
import com.example.constellar.item.SpellTomeItem;
import com.example.constellar.item.StellarWandItem;
import com.example.constellar.spell.Spell;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Constellar.MODID);

    public static final DeferredItem<Item> STELLAR_CRYSTAL =
            ITEMS.registerSimpleItem("stellar_crystal", new Item.Properties());

    public static final DeferredItem<StellarWandItem> STELLAR_WAND =
            ITEMS.registerItem("stellar_wand", StellarWandItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<EnergyReaderItem> ENERGY_READER =
            ITEMS.registerItem("energy_reader", EnergyReaderItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<SpellTomeItem> TOME_FALLING_STAR = ITEMS.registerItem("tome_falling_star",
            props -> new SpellTomeItem(props, Spell.FALLING_STAR), new Item.Properties().stacksTo(1).durability(64));

    public static final DeferredItem<SpellTomeItem> TOME_LEAP = ITEMS.registerItem("tome_leap",
            props -> new SpellTomeItem(props, Spell.STELLAR_LEAP), new Item.Properties().stacksTo(1).durability(64));

    public static final DeferredItem<SpellTomeItem> TOME_HEAL = ITEMS.registerItem("tome_heal",
            props -> new SpellTomeItem(props, Spell.STARLIGHT_HEAL), new Item.Properties().stacksTo(1).durability(64));

    public static final DeferredItem<BlockItem> TELESCOPE =
            ITEMS.registerSimpleBlockItem("telescope", ModBlocks.TELESCOPE);

    public static final DeferredItem<BlockItem> STELLAR_FORGE =
            ITEMS.registerSimpleBlockItem("stellar_forge", ModBlocks.STELLAR_FORGE);

    public static final DeferredItem<BlockItem> STELLAR_STONE =
            ITEMS.registerSimpleBlockItem("stellar_stone", ModBlocks.STELLAR_STONE);

    public static final DeferredItem<BlockItem> STELLAR_PILLAR =
            ITEMS.registerSimpleBlockItem("stellar_pillar", ModBlocks.STELLAR_PILLAR);

    public static final DeferredItem<BlockItem> STELLAR_LENS =
            ITEMS.registerSimpleBlockItem("stellar_lens", ModBlocks.STELLAR_LENS);

    public static final DeferredItem<BlockItem> VOID_CRYSTAL =
            ITEMS.registerSimpleBlockItem("void_crystal", ModBlocks.VOID_CRYSTAL);

    public static final DeferredItem<BlockItem> STARLIGHT_GENERATOR =
            ITEMS.registerSimpleBlockItem("starlight_generator", ModBlocks.STARLIGHT_GENERATOR);

    public static final DeferredItem<BlockItem> STELLAR_BATTERY =
            ITEMS.registerSimpleBlockItem("stellar_battery", ModBlocks.STELLAR_BATTERY);

    private ModItems() {}
}
