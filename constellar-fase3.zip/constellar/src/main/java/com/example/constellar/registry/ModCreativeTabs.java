package com.example.constellar.registry;

import com.example.constellar.Constellar;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Constellar.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.constellar"))
                    .icon(() -> new ItemStack(ModItems.TELESCOPE.get()))
                    .displayItems((params, output) -> {
                        output.accept(ModItems.STELLAR_CRYSTAL.get());
                        output.accept(ModItems.TELESCOPE.get());
                        output.accept(ModItems.STELLAR_WAND.get());
                        output.accept(ModItems.STELLAR_FORGE.get());
                        output.accept(ModItems.STELLAR_STONE.get());
                        output.accept(ModItems.STELLAR_PILLAR.get());
                        output.accept(ModItems.STELLAR_LENS.get());
                        output.accept(ModItems.VOID_CRYSTAL.get());
                        output.accept(ModItems.TOME_FALLING_STAR.get());
                        output.accept(ModItems.TOME_LEAP.get());
                        output.accept(ModItems.TOME_HEAL.get());
                        output.accept(ModItems.STARLIGHT_GENERATOR.get());
                        output.accept(ModItems.STELLAR_BATTERY.get());
                        output.accept(ModItems.ENERGY_READER.get());
                    })
                    .build());

    private ModCreativeTabs() {}
}
