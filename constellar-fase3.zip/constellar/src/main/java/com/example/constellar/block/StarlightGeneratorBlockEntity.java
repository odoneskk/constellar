package com.example.constellar.block;

import com.example.constellar.energy.EnergyUtil;
import com.example.constellar.energy.FEStorage;
import com.example.constellar.registry.ModBlockEntities;
import com.example.constellar.util.Starlight;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

/** Gera FE captando luz das estrelas: precisa ser noite e ter ceu aberto. */
public class StarlightGeneratorBlockEntity extends BlockEntity {
    private static final int BASE_RATE = 40;     // FE por tick
    private static final int PUSH_RATE = 2000;   // FE por tick enviado aos vizinhos

    private final FEStorage energy = new FEStorage(100_000, 0, PUSH_RATE, null);
    private float multiplier = 1.0f;

    public StarlightGeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STARLIGHT_GENERATOR.get(), pos, state);
    }

    public IEnergyStorage getEnergy() {
        return energy;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, StarlightGeneratorBlockEntity be) {
        if (level.getGameTime() % 20 == 0) {
            be.multiplier = Starlight.computeMultiplier(level);
            be.setChanged();
        }
        if (level.dimensionType().hasSkyLight() && Starlight.isNight(level) && level.canSeeSky(pos.above())) {
            be.energy.generate(Math.round(BASE_RATE * be.multiplier));
        }
        EnergyUtil.pushToNeighbors(level, pos, be.energy, PUSH_RATE);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        energy.save(tag);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        energy.load(tag);
    }
}
