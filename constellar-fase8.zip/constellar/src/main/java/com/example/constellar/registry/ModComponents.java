package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModComponents {
    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Constellar.MODID);

    /** Indice da magia selecionada num cajado. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> SELECTED_SPELL =
            COMPONENTS.registerComponentType("selected_spell", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    /** Nivel de aprimoramento de um cajado (0 a 3). */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<Integer>> UPGRADE =
            COMPONENTS.registerComponentType("upgrade", builder -> builder
                    .persistent(Codec.INT)
                    .networkSynchronized(ByteBufCodecs.VAR_INT));

    private ModComponents() {}
}
