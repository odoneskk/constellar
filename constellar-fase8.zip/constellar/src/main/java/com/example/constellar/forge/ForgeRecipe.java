package com.example.constellar.forge;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Receita da Forja Estelar, definida por datapack:
 * data/<namespace>/constellar/forge_recipe/<nome>.json
 * Os itens sao guardados por id, entao receitas com itens de mods ausentes simplesmente nunca acontecem.
 */
public record ForgeRecipe(
        List<ResourceLocation> inputs,
        ResourceLocation result,
        int count,
        Optional<ResourceLocation> constellation,
        int energy
) {
    public static final Codec<ForgeRecipe> CODEC = RecordCodecBuilder.create(i -> i.group(
            ResourceLocation.CODEC.listOf().fieldOf("inputs").forGetter(ForgeRecipe::inputs),
            ResourceLocation.CODEC.fieldOf("result").forGetter(ForgeRecipe::result),
            Codec.intRange(1, 64).optionalFieldOf("count", 1).forGetter(ForgeRecipe::count),
            ResourceLocation.CODEC.optionalFieldOf("constellation").forGetter(ForgeRecipe::constellation),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("energy", 0).forGetter(ForgeRecipe::energy)
    ).apply(i, ForgeRecipe::new));

    /** Os itens na forja precisam ser exatamente os da receita (ordem nao importa). */
    public boolean matches(List<ItemStack> contents) {
        if (contents.size() != inputs.size()) return false;
        Map<ResourceLocation, Integer> need = new HashMap<>();
        for (ResourceLocation id : inputs) need.merge(id, 1, Integer::sum);
        Map<ResourceLocation, Integer> have = new HashMap<>();
        for (ItemStack stack : contents) {
            have.merge(BuiltInRegistries.ITEM.getKey(stack.getItem()), stack.getCount(), Integer::sum);
        }
        return need.equals(have);
    }

    /** O item de resultado, se o mod dele estiver instalado. */
    public Optional<Item> resultItem() {
        return BuiltInRegistries.ITEM.getOptional(result);
    }
}
