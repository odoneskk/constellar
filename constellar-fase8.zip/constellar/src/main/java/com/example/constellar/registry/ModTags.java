package com.example.constellar.registry;

import com.example.constellar.Constellar;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;

/** Tags que permitem a outros mods e modpacks se integrarem sem codigo (itens opcionais com "required": false). */
public final class ModTags {
    /** Itens que ativam a Matriz de Crescimento (60s cada). */
    public static final TagKey<Item> GROWTH_CATALYSTS = item("growth_catalysts");
    /** Material de cada nivel de aprimoramento dos cajados. */
    public static final TagKey<Item> STAFF_UPGRADE_1 = item("staff_upgrade_1");
    public static final TagKey<Item> STAFF_UPGRADE_2 = item("staff_upgrade_2");
    public static final TagKey<Item> STAFF_UPGRADE_3 = item("staff_upgrade_3");
    /** Plantas sem a propriedade "age" que devem crescer por ticks aleatorios (Floracao e ritual). */
    public static final TagKey<Block> GROWTH_EXTRA = TagKey.create(Registries.BLOCK,
            ResourceLocation.fromNamespaceAndPath(Constellar.MODID, "growth_extra"));

    private static TagKey<Item> item(String name) {
        return TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(Constellar.MODID, name));
    }

    private ModTags() {}
}
