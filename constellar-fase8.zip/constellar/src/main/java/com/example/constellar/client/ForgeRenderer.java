package com.example.constellar.client;

import com.example.constellar.block.StellarForgeBlock;
import com.example.constellar.block.StellarForgeBlockEntity;
import com.example.constellar.registry.ModItems;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;

import java.util.List;

/**
 * Forja formada: desenha UM modelo grande 3x3x3 (item oculto "forge_formed") no lugar das 18 pecas
 * e os itens colocados girando em volta do cristal.
 */
public class ForgeRenderer implements BlockEntityRenderer<StellarForgeBlockEntity> {
    private ItemStack modelStack;

    public ForgeRenderer(BlockEntityRendererProvider.Context context) {}

    /** O modelo grande ocupa 3x3 e 3 de altura: precisa ser desenhado mesmo quando o centro sai da tela. */
    public AABB getRenderBoundingBox(StellarForgeBlockEntity be) {
        return new AABB(be.getBlockPos()).inflate(1.5, 0, 1.5).expandTowards(0, 3, 0);
    }

    @Override
    public void render(StellarForgeBlockEntity be, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light, int overlay) {
        if (be.getLevel() == null) return;

        if (be.getBlockState().getValue(StellarForgeBlock.FORMED)) {
            if (modelStack == null) modelStack = new ItemStack(ModItems.FORGE_MODEL.get());
            int modelLight = LevelRenderer.getLightColor(be.getLevel(), be.getBlockPos().above(3));
            pose.pushPose();
            // o modelo usa y deslocado em -1 bloco (limite do formato) e o item e centrado em 0.5
            pose.translate(0.5, 1.5, 0.5);
            Minecraft.getInstance().getItemRenderer().renderStatic(modelStack, ItemDisplayContext.NONE,
                    modelLight, OverlayTexture.NO_OVERLAY, pose, buffer, be.getLevel(), 0);
            pose.popPose();
        }

        List<ItemStack> items = be.contents();
        if (items.isEmpty()) return;

        float time = be.getLevel().getGameTime() + partialTick;
        int n = items.size();
        for (int i = 0; i < n; i++) {
            double angle = time * 0.05 + i * (Math.PI * 2.0 / n);
            pose.pushPose();
            pose.translate(0.5 + Math.cos(angle) * 0.75,
                    2.0 + Math.sin(time * 0.1 + i) * 0.06,
                    0.5 + Math.sin(angle) * 0.75);
            pose.mulPose(Axis.YP.rotationDegrees(time * 2.0F));
            pose.scale(0.4F, 0.4F, 0.4F);
            Minecraft.getInstance().getItemRenderer().renderStatic(items.get(i), ItemDisplayContext.FIXED,
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, pose, buffer, be.getLevel(), i);
            pose.popPose();
        }
    }
}
