package com.example.constellar.block;

import com.example.constellar.registry.ModBlockEntities;
import com.example.constellar.registry.ModItems;
import com.example.constellar.util.GrowthUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;

import java.util.List;

/** Controla o ritual de crescimento: dura 60s por cristal (acumula ate 5 minutos). */
public class GrowthArrayBlockEntity extends BlockEntity {
    private static final int RADIUS = 8;
    private static final int RITUAL_TICKS = 1200;
    private static final int MAX_TICKS = 6000;

    private int remaining;

    public GrowthArrayBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.GROWTH_ARRAY.get(), pos, state);
    }

    /** Gasta um cristal: inicia ou prolonga o ritual. Retorna false se ja estiver no limite. */
    public boolean startRitual() {
        if (remaining >= MAX_TICKS) return false;
        remaining = Math.min(MAX_TICKS, remaining + RITUAL_TICKS);
        setChanged();
        if (level instanceof ServerLevel server) {
            BlockState state = getBlockState();
            if (!state.getValue(GrowthArrayBlock.ACTIVE)) {
                server.setBlock(worldPosition, state.setValue(GrowthArrayBlock.ACTIVE, true), 3);
            }
            server.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.6F);
        }
        return true;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, GrowthArrayBlockEntity be) {
        if (!(level instanceof ServerLevel server)) return;
        boolean active = state.getValue(GrowthArrayBlock.ACTIVE);
        long time = level.getGameTime();

        // cristal jogado no circulo tambem ativa o ritual
        if (time % 10 == 0 && be.remaining < MAX_TICKS) {
            List<ItemEntity> drops = server.getEntitiesOfClass(ItemEntity.class,
                    new AABB(pos).inflate(0.3, 0.1, 0.3).expandTowards(0, 1.0, 0),
                    e -> e.isAlive() && e.getItem().is(ModItems.STELLAR_CRYSTAL.get()));
            for (ItemEntity drop : drops) {
                drop.getItem().shrink(1);
                if (drop.getItem().isEmpty()) drop.discard();
                be.startRitual();
                break;
            }
        }

        if (be.remaining <= 0) {
            if (active) server.setBlock(pos, state.setValue(GrowthArrayBlock.ACTIVE, false), 3);
            return;
        }
        be.remaining--;

        if (time % 10 == 0) {
            GrowthUtil.growArea(server, pos, RADIUS, 1);
            for (int i = 0; i < 10; i++) {
                double angle = level.random.nextDouble() * Math.PI * 2.0;
                double dist = level.random.nextDouble() * RADIUS;
                server.sendParticles(ParticleTypes.HAPPY_VILLAGER,
                        pos.getX() + 0.5 + Math.cos(angle) * dist, pos.getY() + 0.3, pos.getZ() + 0.5 + Math.sin(angle) * dist,
                        1, 0.1, 0.4, 0.1, 0.0);
            }
            server.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5, pos.getY() + 0.3, pos.getZ() + 0.5,
                    3, 0.3, 0.8, 0.3, 0.02);
        }
        if (be.remaining % 100 == 0) be.setChanged();
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putInt("remaining", remaining);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        remaining = tag.getInt("remaining");
    }
}
