package com.example.constellar.multiblock;

import com.example.constellar.block.ForgePartBlock;
import com.example.constellar.block.ForgePartBlockEntity;
import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Forja Estelar (multibloco 3x3):
 *  - centro: Forja Estelar; em cima dela: Cristal do Void
 *  - nas 4 pontas do 3x3 (laterais): Pedra Estelar
 *  - nos 4 cantos: torre de 2 Pilares Estelares com uma Lente Estelar no topo
 * Depois de formada, cada peca vira uma "parte" invisivel e a forja desenha o modelo grande.
 */
public final class ForgeStructure {
    private ForgeStructure() {}

    public record Mismatch(BlockPos pos, Block expected) {}

    /** Posicoes e blocos esperados (sem o centro, que e a propria forja). */
    public static Map<BlockPos, Block> layout(BlockPos forge) {
        Map<BlockPos, Block> map = new LinkedHashMap<>();
        map.put(forge.above(), ModBlocks.VOID_CRYSTAL.get());
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos base = forge.offset(dx, 0, dz);
                if (dx != 0 && dz != 0) {
                    map.put(base, ModBlocks.STELLAR_PILLAR.get());
                    map.put(base.above(), ModBlocks.STELLAR_PILLAR.get());
                    map.put(base.above(2), ModBlocks.STELLAR_LENS.get());
                } else {
                    map.put(base, ModBlocks.STELLAR_STONE.get());
                }
            }
        }
        return map;
    }

    public static List<Mismatch> findAllMismatches(Level level, BlockPos forge) {
        List<Mismatch> missing = new ArrayList<>();
        for (Map.Entry<BlockPos, Block> e : layout(forge).entrySet()) {
            if (!matches(level, e.getKey(), e.getValue())) {
                missing.add(new Mismatch(e.getKey(), e.getValue()));
            }
        }
        return missing;
    }

    @Nullable
    public static Mismatch findMismatch(Level level, BlockPos forge) {
        List<Mismatch> all = findAllMismatches(level, forge);
        return all.isEmpty() ? null : all.get(0);
    }

    /** O bloco esta certo se for o esperado, ou uma parte invisivel que guarda o esperado. */
    private static boolean matches(Level level, BlockPos pos, Block expected) {
        BlockState state = level.getBlockState(pos);
        if (state.is(expected)) return true;
        if (state.getBlock() instanceof ForgePartBlock
                && level.getBlockEntity(pos) instanceof ForgePartBlockEntity part) {
            return part.original() == expected;
        }
        return false;
    }

    /** Quantas torres tem ceu aberto acima da lente (0 a 4). */
    public static int countTowersWithSky(Level level, BlockPos forge) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dz = -1; dz <= 1; dz += 2) {
                if (level.canSeeSky(forge.offset(dx, 3, dz))) count++;
            }
        }
        return count;
    }
}
