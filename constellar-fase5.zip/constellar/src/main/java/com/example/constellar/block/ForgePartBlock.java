package com.example.constellar.block;

import com.example.constellar.multiblock.ForgeAssembly;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/** Parte invisivel de uma Forja Estelar formada: repassa os cliques para a forja e desmonta tudo ao quebrar. */
public class ForgePartBlock extends BaseEntityBlock {
    public static final MapCodec<ForgePartBlock> CODEC = simpleCodec(ForgePartBlock::new);

    public ForgePartBlock(Properties properties) {
        super(properties);
    }

    @Override
    protected MapCodec<? extends BaseEntityBlock> codec() {
        return CODEC;
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    @Override
    protected boolean propagatesSkylightDown(BlockState state, BlockGetter level, BlockPos pos) {
        return true;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new ForgePartBlockEntity(pos, state);
    }

    @Nullable
    private static BlockPos masterOf(Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof ForgePartBlockEntity part ? part.masterPos() : null;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hitResult) {
        BlockPos master = masterOf(level, pos);
        if (master == null) return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        return StellarForgeBlock.interactWithItem(stack, level, master, player);
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        BlockPos master = masterOf(level, pos);
        if (master == null) return InteractionResult.PASS;
        return StellarForgeBlock.interactEmpty(level, master, player);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
        if (level.getBlockEntity(pos) instanceof ForgePartBlockEntity part) {
            return new ItemStack(part.original());
        }
        return ItemStack.EMPTY;
    }

    @Override
    protected void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean movedByPiston) {
        if (!state.is(newState.getBlock()) && level instanceof ServerLevel server && !ForgeAssembly.busy()
                && level.getBlockEntity(pos) instanceof ForgePartBlockEntity part) {
            // devolve a peca quebrada e restaura todas as outras
            Block.popResource(level, pos, new ItemStack(part.original()));
            ForgeAssembly.disassemble(server, part.masterPos(), pos);
        }
        super.onRemove(state, level, pos, newState, movedByPiston);
    }
}
