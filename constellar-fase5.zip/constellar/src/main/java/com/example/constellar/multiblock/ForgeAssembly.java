package com.example.constellar.multiblock;

import com.example.constellar.block.ForgePartBlock;
import com.example.constellar.block.ForgePartBlockEntity;
import com.example.constellar.block.StellarForgeBlock;
import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.Map;

/**
 * Ao formar, as 17 pecas viram "partes" invisiveis ligadas a forja, e a forja passa a desenhar
 * um unico modelo grande. Ao quebrar qualquer peca, tudo volta aos blocos originais.
 */
public final class ForgeAssembly {
    private static boolean busy;

    private ForgeAssembly() {}

    /** Verdadeiro enquanto montamos/desmontamos (evita reentrada nos eventos de remocao). */
    public static boolean busy() {
        return busy;
    }

    public static void assemble(ServerLevel level, BlockPos master) {
        busy = true;
        try {
            for (Map.Entry<BlockPos, Block> e : ForgeStructure.layout(master).entrySet()) {
                BlockPos pos = e.getKey();
                level.setBlock(pos, ModBlocks.FORGE_PART.get().defaultBlockState(), 3);
                if (level.getBlockEntity(pos) instanceof ForgePartBlockEntity part) {
                    part.setData(master, e.getValue());
                }
            }
            BlockState state = level.getBlockState(master);
            if (state.is(ModBlocks.STELLAR_FORGE.get())) {
                level.setBlock(master, state.setValue(StellarForgeBlock.FORMED, true), 3);
            }
        } finally {
            busy = false;
        }
    }

    /** skip: peca que esta sendo quebrada agora (nao e restaurada). */
    public static void disassemble(ServerLevel level, BlockPos master, @Nullable BlockPos skip) {
        busy = true;
        try {
            for (BlockPos pos : ForgeStructure.layout(master).keySet()) {
                if (pos.equals(skip)) continue;
                if (level.getBlockState(pos).getBlock() instanceof ForgePartBlock
                        && level.getBlockEntity(pos) instanceof ForgePartBlockEntity part) {
                    Block original = part.original();
                    level.setBlock(pos, original.defaultBlockState(), 3);
                }
            }
            BlockState state = level.getBlockState(master);
            if (state.is(ModBlocks.STELLAR_FORGE.get()) && state.getValue(StellarForgeBlock.FORMED)) {
                level.setBlock(master, state.setValue(StellarForgeBlock.FORMED, false), 3);
            }
        } finally {
            busy = false;
        }
    }
}
