package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.example.constellar.block.ForgePartBlock;
import com.example.constellar.block.GrowthArrayBlock;
import com.example.constellar.block.StellarBatteryBlock;
import com.example.constellar.block.StellarForgeBlock;
import com.example.constellar.block.StellarPillarBlock;
import com.example.constellar.block.TelescopeBlock;
import com.example.constellar.block.VoidCrystalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredBlock;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlocks {
    public static final DeferredRegister.Blocks BLOCKS = DeferredRegister.createBlocks(Constellar.MODID);

    public static final DeferredBlock<StellarBatteryBlock> STELLAR_BATTERY = BLOCKS.registerBlock(
            "stellar_battery", StellarBatteryBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(3.0f, 6.0f));

    public static final DeferredBlock<TelescopeBlock> TELESCOPE = BLOCKS.registerBlock(
            "telescope", TelescopeBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).strength(2.5f, 5.0f)
                    .sound(SoundType.METAL).noOcclusion());

    public static final DeferredBlock<StellarForgeBlock> STELLAR_FORGE = BLOCKS.registerBlock(
            "stellar_forge", StellarForgeBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(4.0f, 10.0f)
                    .sound(SoundType.METAL).noOcclusion()
                    .lightLevel(state -> state.getValue(StellarForgeBlock.FORMED) ? 12 : 0));

    public static final DeferredBlock<Block> STELLAR_STONE = BLOCKS.registerSimpleBlock(
            "stellar_stone",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(4.0f, 8.0f).sound(SoundType.STONE));

    public static final DeferredBlock<StellarPillarBlock> STELLAR_PILLAR = BLOCKS.registerBlock(
            "stellar_pillar", StellarPillarBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(4.0f, 8.0f)
                    .sound(SoundType.STONE).noOcclusion());

    public static final DeferredBlock<Block> STELLAR_LENS = BLOCKS.registerSimpleBlock(
            "stellar_lens",
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.0f, 6.0f)
                    .sound(SoundType.GLASS).lightLevel(state -> 8));

    public static final DeferredBlock<VoidCrystalBlock> VOID_CRYSTAL = BLOCKS.registerBlock(
            "void_crystal", VoidCrystalBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(3.0f, 8.0f)
                    .sound(SoundType.AMETHYST).noOcclusion().lightLevel(state -> 10));

    /** Parte invisivel de uma forja formada (nao aparece no criativo). */
    public static final DeferredBlock<ForgePartBlock> FORGE_PART = BLOCKS.registerBlock(
            "forge_part", ForgePartBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_BLUE).strength(4.0f, 8.0f)
                    .sound(SoundType.STONE).noOcclusion().lightLevel(state -> 8)
                    .isSuffocating((s, l, p) -> false).isViewBlocking((s, l, p) -> false)
                    .pushReaction(PushReaction.BLOCK));

    public static final DeferredBlock<GrowthArrayBlock> GROWTH_ARRAY = BLOCKS.registerBlock(
            "growth_array", GrowthArrayBlock::new,
            BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_GREEN).strength(1.0f, 4.0f)
                    .sound(SoundType.STONE).noOcclusion()
                    .lightLevel(state -> state.getValue(GrowthArrayBlock.ACTIVE) ? 10 : 0));

    private ModBlocks() {}
}
