package com.example.constellar.spell;

/** As 16 magias do mod. cost = mana, cooldown = ticks. Cada cajado carrega duas. */
public enum StarSpell {
    // Orion: o cacador
    FALLING_STAR("falling_star", 25, 30),
    STARFALL("starfall", 60, 200),
    // Lira: crescimento e colheita (fazendas)
    BLOOM("bloom", 40, 60),
    REAP("reap", 35, 40),
    // Dragao: fogo e forja
    DRAGON_BREATH("dragon_breath", 30, 40),
    STAR_FORGE("star_forge", 45, 80),
    // Cruzeiro do Sul: navegacao
    BLINK("blink", 30, 40),
    RECALL("recall", 120, 1200),
    // Cassiopeia: protecao
    AEGIS("aegis", 50, 400),
    SANCTUARY("sanctuary", 70, 600),
    // Escorpiao: veneno
    STING("sting", 25, 40),
    TOXIC_CLOUD("toxic_cloud", 55, 160),
    // Ursa Maior: coleta e rebanho (fazendas)
    MAGNET("magnet", 20, 40),
    HERD("herd", 40, 200),
    // Cisne: ceu e tempestade
    CLEAR_SKY("clear_sky", 50, 600),
    STORM_CHAIN("storm_chain", 60, 100);

    private final String id;
    private final int cost;
    private final int cooldown;

    StarSpell(String id, int cost, int cooldown) {
        this.id = id;
        this.cost = cost;
        this.cooldown = cooldown;
    }

    public String id() { return id; }
    public int cost() { return cost; }
    public int cooldown() { return cooldown; }
}
