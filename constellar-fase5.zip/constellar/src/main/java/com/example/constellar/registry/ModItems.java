package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.example.constellar.item.ConstellationStaffItem;
import com.example.constellar.item.EnergyReaderItem;
import com.example.constellar.item.StellarWandItem;
import com.example.constellar.spell.StaffType;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Constellar.MODID);

    public static final DeferredItem<Item> STELLAR_CRYSTAL =
            ITEMS.registerSimpleItem("stellar_crystal", new Item.Properties());

    public static final DeferredItem<StellarWandItem> STELLAR_WAND =
            ITEMS.registerItem("stellar_wand", StellarWandItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<EnergyReaderItem> ENERGY_READER =
            ITEMS.registerItem("energy_reader", EnergyReaderItem::new, new Item.Properties().stacksTo(1));

    /** Item oculto: so existe para o modelo grande da Forja Estelar formada. */
    public static final DeferredItem<Item> FORGE_MODEL =
            ITEMS.registerSimpleItem("forge_formed", new Item.Properties());

    /** Um cajado por constelacao: staff_<id>. */
    public static final Map<StaffType, DeferredItem<ConstellationStaffItem>> STAFFS = new EnumMap<>(StaffType.class);

    static {
        for (StaffType type : StaffType.values()) {
            STAFFS.put(type, ITEMS.registerItem("staff_" + type.id(),
                    props -> new ConstellationStaffItem(props, type), new Item.Properties().stacksTo(1)));
        }
    }

    public static final DeferredItem<BlockItem> TELESCOPE =
            ITEMS.registerSimpleBlockItem("telescope", ModBlocks.TELESCOPE);

    public static final DeferredItem<BlockItem> STELLAR_FORGE =
            ITEMS.registerSimpleBlockItem("stellar_forge", ModBlocks.STELLAR_FORGE);

    public static final DeferredItem<BlockItem> STELLAR_STONE =
            ITEMS.registerSimpleBlockItem("stellar_stone", ModBlocks.STELLAR_STONE);

    public static final DeferredItem<BlockItem> STELLAR_PILLAR =
            ITEMS.registerSimpleBlockItem("stellar_pillar", ModBlocks.STELLAR_PILLAR);

    public static final DeferredItem<BlockItem> STELLAR_LENS =
            ITEMS.registerSimpleBlockItem("stellar_lens", ModBlocks.STELLAR_LENS);

    public static final DeferredItem<BlockItem> VOID_CRYSTAL =
            ITEMS.registerSimpleBlockItem("void_crystal", ModBlocks.VOID_CRYSTAL);

    public static final DeferredItem<BlockItem> STELLAR_BATTERY =
            ITEMS.registerSimpleBlockItem("stellar_battery", ModBlocks.STELLAR_BATTERY);

    public static final DeferredItem<BlockItem> GROWTH_ARRAY =
            ITEMS.registerSimpleBlockItem("growth_array", ModBlocks.GROWTH_ARRAY);

    private ModItems() {}
}
