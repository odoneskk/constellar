package com.example.constellar.spell;

import com.example.constellar.Constellar;
import net.minecraft.resources.ResourceLocation;

/** Um cajado por constelacao, cada um com duas magias. */
public enum StaffType {
    ORION("orion", 0xFFD27A, StarSpell.FALLING_STAR, StarSpell.STARFALL),
    LYRA("lyra", 0x7CFF9A, StarSpell.BLOOM, StarSpell.REAP),
    DRACO("draco", 0xFF6A3D, StarSpell.DRAGON_BREATH, StarSpell.STAR_FORGE),
    CRUX("crux", 0x9AB8FF, StarSpell.BLINK, StarSpell.RECALL),
    CASSIOPEIA("cassiopeia", 0xFF9AD5, StarSpell.AEGIS, StarSpell.SANCTUARY),
    SCORPIUS("scorpius", 0xB0FF4A, StarSpell.STING, StarSpell.TOXIC_CLOUD),
    URSA_MAJOR("ursa_major", 0xE0C060, StarSpell.MAGNET, StarSpell.HERD),
    CYGNUS("cygnus", 0xBFE9FF, StarSpell.CLEAR_SKY, StarSpell.STORM_CHAIN);

    private final String id;
    private final int color;
    private final StarSpell[] spells;
    private final ResourceLocation constellation;

    StaffType(String id, int color, StarSpell... spells) {
        this.id = id;
        this.color = color;
        this.spells = spells;
        this.constellation = ResourceLocation.fromNamespaceAndPath(Constellar.MODID, id);
    }

    public String id() { return id; }
    public int color() { return color; }
    public StarSpell[] spells() { return spells; }
    public ResourceLocation constellation() { return constellation; }
}
