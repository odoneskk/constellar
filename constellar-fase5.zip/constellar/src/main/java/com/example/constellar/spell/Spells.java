package com.example.constellar.spell;

import com.example.constellar.util.GrowthUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.AreaEffectCloud;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ExperienceOrb;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.item.crafting.SingleRecipeInput;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Implementacao das 16 magias. power = 1.0 normal, 1.5 quando a constelacao esta ascendente. */
public final class Spells {
    private Spells() {}

    private record Target(Vec3 pos, @Nullable LivingEntity entity) {}

    public static void cast(StarSpell spell, ServerLevel level, ServerPlayer player, float power) {
        switch (spell) {
            case FALLING_STAR -> fallingStar(level, player, power);
            case STARFALL -> starfall(level, player, power);
            case BLOOM -> bloom(level, player, power);
            case REAP -> reap(level, player);
            case DRAGON_BREATH -> dragonBreath(level, player, power);
            case STAR_FORGE -> starForge(level, player);
            case BLINK -> blink(level, player);
            case RECALL -> recall(level, player);
            case AEGIS -> aegis(level, player, power);
            case SANCTUARY -> sanctuary(level, player, player.position(), 0);
            case STING -> sting(level, player, power);
            case TOXIC_CLOUD -> toxicCloud(level, player, power);
            case MAGNET -> magnet(level, player, power);
            case HERD -> herd(level, player);
            case CLEAR_SKY -> clearSky(level, player);
            case STORM_CHAIN -> stormChain(level, player, power);
        }
    }

    // =========================================================== ORION
    private static void fallingStar(ServerLevel level, ServerPlayer p, float power) {
        Target t = trace(level, p, 34.0);
        beam(level, p.getEyePosition(), t.pos(), 0xFFD27A);
        if (t.entity() != null) {
            t.entity().hurt(magic(level, p), 12.0F * power);
        }
        blast(level, p, t.pos(), 2.5, 5.0F * power);
        level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_CLUSTER_BREAK, SoundSource.PLAYERS, 1.3F, 1.4F);
    }

    private static void starfall(ServerLevel level, ServerPlayer p, float power) {
        Target t = trace(level, p, 48.0);
        int meteors = 6 + (int) (3 * power);
        for (int i = 0; i < meteors; i++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            double dist = level.random.nextDouble() * 4.5;
            Vec3 target = new Vec3(t.pos().x + Math.cos(angle) * dist, t.pos().y, t.pos().z + Math.sin(angle) * dist);
            SpellScheduler.later(2 + i * 4, () -> {
                for (int h = 14; h >= 0; h--) {
                    level.sendParticles(ParticleTypes.END_ROD, target.x + h * 0.08, target.y + h, target.z + h * 0.08,
                            1, 0.05, 0.05, 0.05, 0.0);
                    if (h % 3 == 0) {
                        level.sendParticles(ParticleTypes.FLAME, target.x + h * 0.08, target.y + h, target.z + h * 0.08,
                                2, 0.1, 0.1, 0.1, 0.0);
                    }
                }
                blast(level, p, target, 2.8, 8.0F * power);
            });
        }
        level.playSound(null, BlockPos.containing(t.pos()), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.2F, 0.6F);
    }

    // =========================================================== LIRA (fazendas)
    private static void bloom(ServerLevel level, ServerPlayer p, float power) {
        int grown = GrowthUtil.growArea(level, p.blockPosition(), 7, 2 + (int) power);
        ring(level, p.position(), 7, ParticleTypes.HAPPY_VILLAGER);
        level.playSound(null, p.blockPosition(), SoundEvents.BONE_MEAL_USE, SoundSource.PLAYERS, 1.2F, 1.0F);
        p.displayClientMessage(Component.translatable("message.constellar.spell_grew", grown), true);
    }

    private static void reap(ServerLevel level, ServerPlayer p) {
        int harvested = GrowthUtil.harvestArea(level, p, p.blockPosition(), 7);
        ring(level, p.position(), 7, ParticleTypes.COMPOSTER);
        level.playSound(null, p.blockPosition(), SoundEvents.CROP_BREAK, SoundSource.PLAYERS, 1.2F, 1.0F);
        p.displayClientMessage(Component.translatable("message.constellar.spell_reaped", harvested), true);
    }

    // =========================================================== DRACO
    private static void dragonBreath(ServerLevel level, ServerPlayer p, float power) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        double reach = 9.0;
        for (LivingEntity target : level.getEntitiesOfClass(LivingEntity.class, p.getBoundingBox().inflate(reach),
                e -> e != p && e.isAlive() && !e.isSpectator())) {
            Vec3 to = target.getEyePosition().subtract(eye);
            double dist = to.length();
            if (dist > reach || dist < 0.1 || to.normalize().dot(look) < 0.78) continue;
            target.hurt(magic(level, p), 5.0F * power);
            target.setRemainingFireTicks(120);
        }
        for (double d = 1.0; d <= reach; d += 0.8) {
            Vec3 pos = eye.add(look.scale(d));
            double spread = 0.12 + d * 0.06;
            level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 4, spread, spread, spread, 0.02);
            level.sendParticles(ParticleTypes.SMOKE, pos.x, pos.y, pos.z, 1, spread, spread, spread, 0.01);
        }
        level.playSound(null, p.blockPosition(), SoundEvents.BLAZE_SHOOT, SoundSource.PLAYERS, 1.2F, 0.7F);
    }

    /** Cozinha todos os itens no chao ao redor, como uma fornalha instantanea. */
    private static void starForge(ServerLevel level, ServerPlayer p) {
        int cooked = 0;
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, p.getBoundingBox().inflate(7.0), ItemEntity::isAlive)) {
            ItemStack stack = item.getItem();
            var recipe = level.getRecipeManager().getRecipeFor(RecipeType.SMELTING, new SingleRecipeInput(stack), level);
            if (recipe.isEmpty()) continue;
            ItemStack out = recipe.get().value().getResultItem(level.registryAccess()).copy();
            if (out.isEmpty()) continue;
            out.setCount(out.getCount() * stack.getCount());
            item.setItem(out);
            level.sendParticles(ParticleTypes.FLAME, item.getX(), item.getY() + 0.3, item.getZ(), 8, 0.2, 0.2, 0.2, 0.02);
            cooked++;
        }
        level.playSound(null, p.blockPosition(), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.0F, 1.2F);
        p.displayClientMessage(Component.translatable("message.constellar.spell_cooked", cooked), true);
    }

    // =========================================================== CRUZEIRO DO SUL
    private static void blink(ServerLevel level, ServerPlayer p) {
        Vec3 eye = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 end = eye.add(dir.scale(12.0));
        BlockHitResult hit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        Vec3 feet;
        if (hit.getType() == HitResult.Type.MISS) {
            feet = end.subtract(0, p.getEyeHeight(), 0);
        } else if (hit.getDirection() == Direction.UP) {
            feet = hit.getLocation();
        } else {
            feet = hit.getLocation().subtract(dir.scale(0.6)).subtract(0, p.getEyeHeight(), 0);
        }
        level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.4, 0.8, 0.4, 0.3);
        p.teleportTo(feet.x, feet.y + 0.05, feet.z);
        int tries = 0;
        while (!level.noCollision(p) && tries++ < 4) {
            p.teleportTo(p.getX(), p.getY() + 1.0, p.getZ());
        }
        p.fallDistance = 0.0F;
        level.sendParticles(ParticleTypes.PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 40, 0.4, 0.8, 0.4, 0.3);
        level.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
    }

    /** Volta para a cama (ou para o spawn do mundo), mesmo em outra dimensao. */
    private static void recall(ServerLevel level, ServerPlayer p) {
        BlockPos spawn = p.getRespawnPosition();
        ServerLevel target = spawn != null ? level.getServer().getLevel(p.getRespawnDimension()) : level.getServer().overworld();
        if (target == null) target = level.getServer().overworld();
        if (spawn == null) spawn = target.getSharedSpawnPos();
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 60, 0.4, 0.9, 0.4, 0.4);
        p.teleportTo(target, spawn.getX() + 0.5, spawn.getY() + 0.1, spawn.getZ() + 0.5, p.getYRot(), p.getXRot());
        target.sendParticles(ParticleTypes.REVERSE_PORTAL, p.getX(), p.getY() + 1.0, p.getZ(), 60, 0.4, 0.9, 0.4, 0.4);
        target.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.7F);
    }

    // =========================================================== CASSIOPEIA
    private static void aegis(ServerLevel level, ServerPlayer p, float power) {
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, (int) (600 * power), 2));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, (int) (300 * power), 1));
        level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.6, 0.9, 0.6, 0.02);
        level.sendParticles(ParticleTypes.ENCHANT, p.getX(), p.getY() + 1.0, p.getZ(), 30, 0.6, 0.9, 0.6, 0.5);
        level.playSound(null, p.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.2F, 1.4F);
    }

    /** Santuario: por 15 segundos, monstros num raio de 10 blocos sao afastados e perdem o alvo. */
    private static void sanctuary(ServerLevel level, ServerPlayer p, Vec3 center, int elapsed) {
        double radius = 10.0;
        for (Monster mob : level.getEntitiesOfClass(Monster.class, new AABB(center, center).inflate(radius),
                m -> m.isAlive() && m.position().distanceTo(center) <= radius)) {
            Vec3 away = mob.position().subtract(center);
            Vec3 flat = new Vec3(away.x, 0, away.z);
            if (flat.lengthSqr() < 1.0E-4) flat = new Vec3(1, 0, 0);
            Vec3 push = flat.normalize().scale(0.45);
            mob.setDeltaMovement(mob.getDeltaMovement().add(push.x, 0.1, push.z));
            mob.hurtMarked = true;
            mob.setTarget(null);
        }
        for (int i = 0; i < 24; i++) {
            double a = i * (Math.PI * 2.0 / 24.0) + elapsed * 0.05;
            level.sendParticles(ParticleTypes.END_ROD, center.x + Math.cos(a) * radius, center.y + 0.2,
                    center.z + Math.sin(a) * radius, 1, 0.0, 0.1, 0.0, 0.0);
        }
        if (elapsed == 0) {
            level.playSound(null, BlockPos.containing(center), SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 1.0F, 1.8F);
        }
        if (elapsed < 300) {
            SpellScheduler.later(5, () -> sanctuary(level, p, center, elapsed + 5));
        }
    }

    // =========================================================== ESCORPIAO
    private static void sting(ServerLevel level, ServerPlayer p, float power) {
        Target t = trace(level, p, 30.0);
        beam(level, p.getEyePosition(), t.pos(), 0xB0FF4A);
        if (t.entity() != null) {
            LivingEntity e = t.entity();
            e.hurt(magic(level, p), 6.0F * power);
            e.addEffect(new MobEffectInstance(MobEffects.POISON, (int) (200 * power), 1));
            e.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 0));
            e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 0));
        }
        level.playSound(null, p.blockPosition(), SoundEvents.SPIDER_HURT, SoundSource.PLAYERS, 1.0F, 1.6F);
    }

    private static void toxicCloud(ServerLevel level, ServerPlayer p, float power) {
        Target t = trace(level, p, 28.0);
        AreaEffectCloud cloud = new AreaEffectCloud(level, t.pos().x, t.pos().y, t.pos().z);
        cloud.setOwner(p);
        cloud.setRadius(3.5F * power);
        cloud.setDuration(240);
        cloud.setRadiusPerTick(-0.004F);
        cloud.setParticle(ParticleTypes.ENTITY_EFFECT);
        cloud.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 1));
        cloud.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 100, 0));
        cloud.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 0));
        level.addFreshEntity(cloud);
        level.playSound(null, BlockPos.containing(t.pos()), SoundEvents.GENERIC_SPLASH, SoundSource.PLAYERS, 1.0F, 0.6F);
    }

    // =========================================================== URSA MAIOR (fazendas)
    private static void magnet(ServerLevel level, ServerPlayer p, float power) {
        double radius = 12.0 * power;
        AABB box = p.getBoundingBox().inflate(radius);
        int count = 0;
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box, ItemEntity::isAlive)) {
            item.setPos(p.getX(), p.getY() + 0.3, p.getZ());
            item.setDeltaMovement(Vec3.ZERO);
            item.setPickUpDelay(0);
            count++;
        }
        for (ExperienceOrb orb : level.getEntitiesOfClass(ExperienceOrb.class, box, ExperienceOrb::isAlive)) {
            orb.setPos(p.getX(), p.getY() + 0.3, p.getZ());
            count++;
        }
        ring(level, p.position(), 4, ParticleTypes.PORTAL);
        level.playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.6F, 1.8F);
        p.displayClientMessage(Component.translatable("message.constellar.spell_pulled", count), true);
    }

    /** Coloca os animais adultos num raio de 10 blocos em modo de reproducao. */
    private static void herd(ServerLevel level, ServerPlayer p) {
        int count = 0;
        for (Animal animal : level.getEntitiesOfClass(Animal.class, p.getBoundingBox().inflate(10.0), Animal::isAlive)) {
            if (animal.getAge() == 0 && animal.canFallInLove()) {
                animal.setInLove(p);
                count++;
            }
        }
        ring(level, p.position(), 10, ParticleTypes.HEART);
        level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 1.3F);
        p.displayClientMessage(Component.translatable("message.constellar.spell_bred", count), true);
    }

    // =========================================================== CISNE
    private static void clearSky(ServerLevel level, ServerPlayer p) {
        if (!level.isRaining() && !level.isThundering()) {
            p.displayClientMessage(Component.translatable("message.constellar.spell_sky_already"), true);
        } else {
            level.setWeatherParameters(24000, 0, false, false);
            p.displayClientMessage(Component.translatable("message.constellar.spell_sky_cleared"), true);
        }
        level.sendParticles(ParticleTypes.END_ROD, p.getX(), p.getY() + 2.0, p.getZ(), 30, 1.0, 0.6, 1.0, 0.05);
        level.playSound(null, p.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.2F, 1.6F);
    }

    private static void stormChain(ServerLevel level, ServerPlayer p, float power) {
        Target t = trace(level, p, 32.0);
        List<Vec3> strikes = new ArrayList<>();
        List<LivingEntity> victims = new ArrayList<>();
        if (t.entity() != null) {
            victims.add(t.entity());
            List<LivingEntity> near = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class,
                    t.entity().getBoundingBox().inflate(8.0),
                    e -> e != p && e != t.entity() && e.isAlive() && !e.isSpectator()));
            near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(t.entity())));
            for (int i = 0; i < Math.min(3, near.size()); i++) victims.add(near.get(i));
        }
        if (victims.isEmpty()) strikes.add(t.pos());
        for (LivingEntity v : victims) strikes.add(v.position());

        for (Vec3 pos : strikes) {
            LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
            if (bolt != null) {
                bolt.moveTo(pos.x, pos.y, pos.z);
                bolt.setVisualOnly(true);
                level.addFreshEntity(bolt);
            }
        }
        for (LivingEntity v : victims) {
            v.hurt(magic(level, p), 9.0F * power);
            v.setRemainingFireTicks(40);
        }
    }

    // =========================================================== UTIL
    private static DamageSource magic(ServerLevel level, ServerPlayer p) {
        return level.damageSources().indirectMagic(p, p);
    }

    /** Raio do olhar: bloco ou criatura atingida. */
    private static Target trace(ServerLevel level, ServerPlayer p, double range) {
        Vec3 start = p.getEyePosition();
        Vec3 dir = p.getLookAngle();
        Vec3 end = start.add(dir.scale(range));
        BlockHitResult block = level.clip(new ClipContext(start, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        boolean hitBlock = block.getType() != HitResult.Type.MISS;
        if (hitBlock) end = block.getLocation();

        AABB box = p.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(p, start, end, box,
                e -> e instanceof LivingEntity && !e.isSpectator() && e.isPickable(), range * range);
        if (entityHit != null && entityHit.getEntity() instanceof LivingEntity living) {
            return new Target(entityHit.getLocation(), living);
        }
        Vec3 pos = hitBlock ? end.subtract(dir.scale(0.3)) : end;
        return new Target(pos, null);
    }

    private static void beam(ServerLevel level, Vec3 from, Vec3 to, int rgb) {
        Vec3 path = to.subtract(from);
        double length = path.length();
        if (length < 0.5) return;
        Vec3 unit = path.normalize();
        DustParticleOptions dust = new DustParticleOptions(new Vector3f(
                ((rgb >> 16) & 255) / 255.0F, ((rgb >> 8) & 255) / 255.0F, (rgb & 255) / 255.0F), 1.1F);
        for (double d = 0.8; d < length; d += 0.35) {
            Vec3 p = from.add(unit.scale(d));
            level.sendParticles(dust, p.x, p.y - 0.1, p.z, 1, 0.0, 0.0, 0.0, 0.0);
            if (((int) (d * 10)) % 5 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, p.x, p.y - 0.1, p.z, 1, 0.03, 0.03, 0.03, 0.0);
            }
        }
    }

    private static void ring(ServerLevel level, Vec3 center, double radius, net.minecraft.core.particles.SimpleParticleType type) {
        for (int i = 0; i < 40; i++) {
            double a = i * (Math.PI * 2.0 / 40.0);
            level.sendParticles(type, center.x + Math.cos(a) * radius, center.y + 0.3, center.z + Math.sin(a) * radius,
                    1, 0.1, 0.2, 0.1, 0.0);
        }
    }

    /** Explosao magica: dano e empurrao em area, sem destruir blocos. */
    private static void blast(ServerLevel level, ServerPlayer caster, Vec3 pos, double radius, float damage) {
        level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 2, 0.3, 0.3, 0.3, 0.0);
        level.sendParticles(ParticleTypes.FIREWORK, pos.x, pos.y, pos.z, 25, radius * 0.25, radius * 0.25, radius * 0.25, 0.1);
        level.playSound(null, BlockPos.containing(pos), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST, SoundSource.PLAYERS, 1.2F, 0.8F);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                x -> x != caster && x.isAlive() && !x.isSpectator())) {
            double d = e.position().distanceTo(pos);
            if (d > radius) continue;
            float scaled = (float) (damage * (1.0 - d / (radius * 1.3)));
            e.hurt(magic(level, caster), Math.max(1.0F, scaled));
            Vec3 push = e.position().subtract(pos);
            if (push.lengthSqr() > 1.0E-4) {
                push = push.normalize().scale(0.7);
                e.setDeltaMovement(e.getDeltaMovement().add(push.x, 0.3, push.z));
                e.hurtMarked = true;
            }
        }
    }
}
