package com.example.constellar.util;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.DoublePlantBlock;
import net.minecraft.world.level.block.GrassBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.NyliumBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.block.state.properties.Property;

import java.util.Collections;

/**
 * Faz plantas crescerem sem depender de luz, agua ou fazenda especial.
 * Funciona com qualquer cultura que tenha a propriedade "age" (Mystical Agriculture, Farmer's Delight...)
 * e com qualquer planta "bonemealable" de outros mods.
 */
public final class GrowthUtil {
    private GrowthUtil() {}

    /** Avanca o crescimento de tudo no cubo ao redor do centro. Retorna quantas plantas avancaram. */
    public static int growArea(ServerLevel level, BlockPos center, int radius, int steps) {
        int grown = 0;
        for (BlockPos scan : BlockPos.betweenClosed(
                center.offset(-radius, -2, -radius), center.offset(radius, 3, radius))) {
            BlockPos pos = scan.immutable();
            for (int i = 0; i < steps; i++) {
                if (!growOnce(level, pos, level.getBlockState(pos))) break;
                grown++;
            }
        }
        return grown;
    }

    private static boolean growOnce(ServerLevel level, BlockPos pos, BlockState state) {
        if (state.isAir()) return false;
        Block block = state.getBlock();
        if (block instanceof GrassBlock || block instanceof NyliumBlock || block instanceof DoublePlantBlock) return false;

        boolean plant = block instanceof CropBlock || block instanceof StemBlock || block instanceof NetherWartBlock
                || block instanceof SweetBerryBushBlock || block instanceof CocoaBlock
                || block instanceof SugarCaneBlock || block instanceof CactusBlock
                || block instanceof BonemealableBlock;
        if (!plant) return false;

        for (Property<?> property : state.getProperties()) {
            if (property instanceof IntegerProperty age && property.getName().equals("age")) {
                int current = state.getValue(age);
                int max = Collections.max(age.getPossibleValues());
                if (current < max) {
                    level.setBlock(pos, state.setValue(age, current + 1), 2);
                    level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.4, pos.getZ() + 0.5,
                            1, 0.25, 0.2, 0.25, 0.0);
                    return true;
                }
                if (block instanceof StemBlock) {
                    state.randomTick(level, pos, level.random);
                }
                return false;
            }
        }

        if (block instanceof BonemealableBlock bonemealable
                && bonemealable.isValidBonemealTarget(level, pos, state)) {
            bonemealable.performBonemeal(level, level.random, pos, state);
            level.sendParticles(ParticleTypes.HAPPY_VILLAGER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                    2, 0.3, 0.3, 0.3, 0.0);
            return true;
        }
        return false;
    }

    /** Colhe culturas maduras (qualquer CropBlock, inclusive Mystical Agriculture) e replanta. */
    public static int harvestArea(ServerLevel level, net.minecraft.world.entity.player.Player player,
                                  BlockPos center, int radius) {
        int harvested = 0;
        for (BlockPos scan : BlockPos.betweenClosed(
                center.offset(-radius, -2, -radius), center.offset(radius, 3, radius))) {
            BlockPos pos = scan.immutable();
            BlockState state = level.getBlockState(pos);
            if (state.getBlock() instanceof CropBlock crop && crop.isMaxAge(state)) {
                level.destroyBlock(pos, true, player);
                BlockState replant = crop.getStateForAge(0);
                if (replant.canSurvive(level, pos)) {
                    level.setBlock(pos, replant, 3);
                }
                level.sendParticles(ParticleTypes.COMPOSTER, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        4, 0.25, 0.25, 0.25, 0.0);
                harvested++;
            }
        }
        return harvested;
    }
}
