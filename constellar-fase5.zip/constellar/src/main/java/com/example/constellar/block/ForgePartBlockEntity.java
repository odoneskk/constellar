package com.example.constellar.block;

import com.example.constellar.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/** Guarda qual forja manda nesta parte e qual era o bloco original. */
public class ForgePartBlockEntity extends BlockEntity {
    private BlockPos master = BlockPos.ZERO;
    private ResourceLocation original = ResourceLocation.withDefaultNamespace("stone");

    public ForgePartBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.FORGE_PART.get(), pos, state);
    }

    public void setData(BlockPos master, Block original) {
        this.master = master;
        this.original = BuiltInRegistries.BLOCK.getKey(original);
        setChanged();
    }

    public BlockPos masterPos() {
        return master;
    }

    public Block original() {
        return BuiltInRegistries.BLOCK.get(original);
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        tag.putLong("master", master.asLong());
        tag.putString("original", original.toString());
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        master = BlockPos.of(tag.getLong("master"));
        original = ResourceLocation.parse(tag.getString("original"));
    }
}
