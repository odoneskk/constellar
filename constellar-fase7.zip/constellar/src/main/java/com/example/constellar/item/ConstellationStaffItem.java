package com.example.constellar.item;

import com.example.constellar.mana.ManaManager;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.registry.ModComponents;
import com.example.constellar.spell.Spells;
import com.example.constellar.spell.StaffType;
import com.example.constellar.spell.StarSpell;
import com.example.constellar.util.Starlight;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * Cajado de uma constelacao. Botao direito lanca a magia selecionada; agachado + botao direito troca de magia.
 * Quando a fase da lua favorece a constelacao ("ascendente"), a magia custa metade da mana e sai 50% mais forte.
 */
public class ConstellationStaffItem extends Item {
    private final StaffType type;

    public ConstellationStaffItem(Properties properties, StaffType type) {
        super(properties);
        this.type = type;
    }

    public StaffType type() {
        return type;
    }

    public static StarSpell selected(ItemStack stack, StaffType type) {
        int index = stack.getOrDefault(ModComponents.SELECTED_SPELL.get(), 0);
        StarSpell[] spells = type.spells();
        return spells[Math.floorMod(index, spells.length)];
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        if (player.isShiftKeyDown()) {
            int next = Math.floorMod(stack.getOrDefault(ModComponents.SELECTED_SPELL.get(), 0) + 1, type.spells().length);
            stack.set(ModComponents.SELECTED_SPELL.get(), next);
            player.displayClientMessage(Component.translatable("message.constellar.spell_selected",
                    Component.translatable("spell.constellar." + type.spells()[next].id())), true);
            return InteractionResultHolder.sidedSuccess(stack, false);
        }

        if (!player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS).contains(type.constellation())) {
            player.displayClientMessage(Component.translatable("message.constellar.staff_locked",
                    Starlight.constellationName(server, type.constellation())), true);
            return InteractionResultHolder.fail(stack);
        }

        StarSpell spell = selected(stack, type);
        boolean ascendant = Starlight.isAscendant(server, type.constellation());
        int level = stack.getOrDefault(ModComponents.UPGRADE.get(), 0);
        int cost = Math.max(1, Math.round(spell.cost() * (1.0F - 0.15F * level) * (ascendant ? 0.5F : 1.0F)));
        if (!ManaManager.consume(serverPlayer, cost)) {
            player.displayClientMessage(Component.translatable("message.constellar.mana_insufficient",
                    ManaManager.get(serverPlayer), cost), true);
            return InteractionResultHolder.fail(stack);
        }

        Spells.cast(spell, server, serverPlayer, (ascendant ? 1.5F : 1.0F) * (1.0F + 0.25F * level));
        player.getCooldowns().addCooldown(this, spell.cooldown());
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        StarSpell current = selected(stack, type);
        for (StarSpell spell : type.spells()) {
            boolean isCurrent = spell == current;
            tooltip.add(Component.literal(isCurrent ? "> " : "  ")
                    .append(Component.translatable("spell.constellar." + spell.id()))
                    .append(Component.literal("  (" + spell.cost() + ")"))
                    .withStyle(isCurrent ? ChatFormatting.AQUA : ChatFormatting.DARK_GRAY));
        }
        int level = stack.getOrDefault(ModComponents.UPGRADE.get(), 0);
        if (level > 0) {
            tooltip.add(Component.translatable("tooltip.constellar.staff_level", level).withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.constellar.staff_hint").withStyle(ChatFormatting.GRAY));
    }
}
