# Constellar (nome provisório) — fase 7

Mod para Minecraft 1.21.1 / NeoForge 21.1.x. Livro de guia: precisa do **Modonomicon 1.21.1** instalado.

## Progressão
1. **Telescópio** (bloco 3D): leia as estrelas à noite; as constelações aparecem desenhadas no céu.
2. **Forja Estelar** (multibloco 3x3, estilo Immersive Engineering): ao formar, as peças se fundem num único
   modelo grande e animado; quebrar qualquer peça desmonta tudo. Ative com a Varinha Estelar
   (nuvens azuis mostram o que falta).
3. **Cajados Constelares**: um por constelação, cada um com 2 magias. Botão direito lança, agachado troca de magia.
4. **Matriz de Crescimento** (ritual): clique ou jogue um Cristal Estelar e as plantas num raio de 8 blocos
   crescem muito rápido (Mystical Agriculture e outras culturas por estágio).

## Magias (16)
Órion: Estrela Cadente, Chuva de Meteoros | Lira: Floração, Colheita Estelar | Dragão: Sopro do Dragão, Fornalha Estelar |
Cruzeiro: Passo Dimensional, Retorno Estelar | Cassiopeia: Égide, Santuário | Escorpião: Ferrão, Nuvem Tóxica |
Ursa Maior: Ímã Estelar, Chamado do Rebanho | Cisne: Céu Limpo, Corrente de Raios

Mana: 100 + 20 por constelação; recarga 4/s (10/s à noite sob o céu aberto).
Constelação ascendente (fase da lua favorita, à noite): metade da mana e +50% de força.

## Compilar
GitHub Actions. O .jar sai em `build/libs/constellar-0.6.0.jar`.

## Integrações (todas opcionais, por tags e dados)
- Energia FE com qualquer mod; Modonomicon (livro); Mystical Agriculture (ritual e essências como catalisador);
  All the Modium (lingotes aprimoram os cajados: níveis 1 a 3).
- Tags: `constellar:growth_catalysts`, `constellar:staff_upgrade_1/2/3`, `constellar:growth_extra`.
- Receitas da forja em `data/<mod>/constellar/forge_recipe/` (funcionam com KubeJS).
