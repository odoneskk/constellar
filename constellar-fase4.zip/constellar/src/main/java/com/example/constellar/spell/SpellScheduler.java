package com.example.constellar.spell;

import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/** Executa tarefas daqui a N ticks do servidor (meteoros, buraco negro...). */
public final class SpellScheduler {
    private static final class Task {
        int ticks;
        final Runnable run;
        Task(int ticks, Runnable run) {
            this.ticks = ticks;
            this.run = run;
        }
    }

    private static final List<Task> TASKS = new ArrayList<>();

    private SpellScheduler() {}

    public static void later(int delayTicks, Runnable run) {
        TASKS.add(new Task(Math.max(1, delayTicks), run));
    }

    public static void onServerTick(ServerTickEvent.Post event) {
        if (TASKS.isEmpty()) return;
        List<Runnable> due = new ArrayList<>();
        Iterator<Task> it = TASKS.iterator();
        while (it.hasNext()) {
            Task task = it.next();
            if (--task.ticks <= 0) {
                due.add(task.run);
                it.remove();
            }
        }
        for (Runnable r : due) {
            try {
                r.run();
            } catch (RuntimeException ignored) {
                // uma magia com erro nao pode derrubar o servidor
            }
        }
    }
}
