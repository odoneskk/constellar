package com.example.constellar.forge;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Receita da Forja Estelar, definida por datapack:
 * data/<namespace>/constellar/forge_recipe/<nome>.json
 */
public record ForgeRecipe(
        List<Item> inputs,
        Item result,
        int count,
        Optional<ResourceLocation> constellation,
        int energy
) {
    public static final Codec<ForgeRecipe> CODEC = RecordCodecBuilder.create(i -> i.group(
            BuiltInRegistries.ITEM.byNameCodec().listOf().fieldOf("inputs").forGetter(ForgeRecipe::inputs),
            BuiltInRegistries.ITEM.byNameCodec().fieldOf("result").forGetter(ForgeRecipe::result),
            Codec.intRange(1, 64).optionalFieldOf("count", 1).forGetter(ForgeRecipe::count),
            ResourceLocation.CODEC.optionalFieldOf("constellation").forGetter(ForgeRecipe::constellation),
            Codec.intRange(0, Integer.MAX_VALUE).optionalFieldOf("energy", 0).forGetter(ForgeRecipe::energy)
    ).apply(i, ForgeRecipe::new));

    /** Os itens na forja precisam ser exatamente os da receita (ordem nao importa). */
    public boolean matches(List<ItemStack> contents) {
        if (contents.size() != inputs.size()) return false;
        Map<Item, Integer> need = new HashMap<>();
        for (Item item : inputs) need.merge(item, 1, Integer::sum);
        Map<Item, Integer> have = new HashMap<>();
        for (ItemStack stack : contents) have.merge(stack.getItem(), stack.getCount(), Integer::sum);
        return need.equals(have);
    }
}
