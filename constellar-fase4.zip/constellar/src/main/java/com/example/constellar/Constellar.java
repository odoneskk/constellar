package com.example.constellar;

import com.example.constellar.constellation.Constellation;
import com.example.constellar.constellation.ConstellationRegistry;
import com.example.constellar.forge.ForgeRecipe;
import com.example.constellar.forge.ForgeRecipeRegistry;
import com.example.constellar.mana.ManaManager;
import com.example.constellar.multiblock.GhostHints;
import com.example.constellar.network.SyncConstellationsPayload;
import com.example.constellar.network.SyncManaPayload;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.registry.ModBlockEntities;
import com.example.constellar.registry.ModBlocks;
import com.example.constellar.registry.ModComponents;
import com.example.constellar.registry.ModCreativeTabs;
import com.example.constellar.registry.ModEntities;
import com.example.constellar.registry.ModItems;
import com.example.constellar.spell.SpellScheduler;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;
import net.neoforged.neoforge.registries.DataPackRegistryEvent;

@Mod(Constellar.MODID)
public class Constellar {
    public static final String MODID = "constellar";

    public Constellar(IEventBus modBus) {
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModComponents.COMPONENTS.register(modBus);
        ModCreativeTabs.TABS.register(modBus);
        ModAttachments.ATTACHMENTS.register(modBus);

        modBus.addListener(this::registerCapabilities);
        modBus.addListener(this::registerDatapackRegistries);
        modBus.addListener(this::registerPayloads);

        NeoForge.EVENT_BUS.addListener(this::onPlayerLogin);
        NeoForge.EVENT_BUS.addListener(GhostHints::onServerTick);
        NeoForge.EVENT_BUS.addListener(SpellScheduler::onServerTick);
        NeoForge.EVENT_BUS.addListener(ManaManager::onPlayerTick);
    }

    /** Energia FE padrao: compativel com cabos e maquinas de outros mods (ATM10 etc.). */
    private void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK,
                ModBlockEntities.STELLAR_BATTERY.get(), (be, side) -> be.getEnergy());
        event.registerBlockEntity(Capabilities.EnergyStorage.BLOCK,
                ModBlockEntities.STELLAR_FORGE.get(), (be, side) -> be.getEnergy());
    }

    private void registerDatapackRegistries(DataPackRegistryEvent.NewRegistry event) {
        event.dataPackRegistry(ConstellationRegistry.KEY, Constellation.CODEC, Constellation.CODEC);
        event.dataPackRegistry(ForgeRecipeRegistry.KEY, ForgeRecipe.CODEC);
    }

    private void registerPayloads(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar registrar = event.registrar("1");
        registrar.playToClient(SyncConstellationsPayload.TYPE, SyncConstellationsPayload.STREAM_CODEC,
                SyncConstellationsPayload::handle);
        registrar.playToClient(SyncManaPayload.TYPE, SyncManaPayload.STREAM_CODEC,
                SyncManaPayload::handle);
    }

    private void onPlayerLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer player) {
            PacketDistributor.sendToPlayer(player,
                    new SyncConstellationsPayload(player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS)));
            ManaManager.sync(player);
        }
    }
}
