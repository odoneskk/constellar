package com.example.constellar.block;

import com.example.constellar.energy.FEStorage;
import com.example.constellar.forge.ForgeRecipe;
import com.example.constellar.forge.ForgeRecipeRegistry;
import com.example.constellar.item.GlyphItem;
import com.example.constellar.multiblock.ForgeStructure;
import com.example.constellar.multiblock.GhostHints;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.registry.ModBlockEntities;
import com.example.constellar.registry.ModComponents;
import com.example.constellar.registry.ModItems;
import com.example.constellar.spell.ParsedSpell;
import com.example.constellar.util.Starlight;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.core.Registry;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class StellarForgeBlockEntity extends BlockEntity {
    public static final int SLOTS = 8;
    private static final int CHARGE_PER_TOWER = 10; // FE por tick, por torre com ceu aberto

    private final NonNullList<ItemStack> items = NonNullList.withSize(SLOTS, ItemStack.EMPTY);
    private final FEStorage energy = new FEStorage(100_000, 5_000, 0, this::setChanged);
    private float multiplier = 1.0f;

    public StellarForgeBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STELLAR_FORGE.get(), pos, state);
    }

    public IEnergyStorage getEnergy() {
        return energy;
    }

    // ---------- itens na forja ----------
    public List<ItemStack> contents() {
        List<ItemStack> list = new ArrayList<>();
        for (ItemStack s : items) if (!s.isEmpty()) list.add(s);
        return list;
    }

    public boolean addItem(ItemStack single) {
        for (int i = 0; i < SLOTS; i++) {
            if (items.get(i).isEmpty()) {
                items.set(i, single);
                itemsChanged();
                return true;
            }
        }
        return false;
    }

    public ItemStack removeLast() {
        for (int i = SLOTS - 1; i >= 0; i--) {
            if (!items.get(i).isEmpty()) {
                ItemStack out = items.get(i);
                items.set(i, ItemStack.EMPTY);
                itemsChanged();
                return out;
            }
        }
        return ItemStack.EMPTY;
    }

    public void dropContents() {
        if (level == null) return;
        for (ItemStack s : items) {
            if (!s.isEmpty()) Block.popResource(level, worldPosition, s);
        }
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
    }

    private void itemsChanged() {
        setChanged();
        if (level != null) {
            BlockState state = getBlockState();
            level.sendBlockUpdated(worldPosition, state, state, Block.UPDATE_ALL);
        }
    }

    // ---------- ativar (varinha) ----------
    public void activate(Player player) {
        if (!(level instanceof ServerLevel server)) return;
        BlockState state = getBlockState();
        boolean formed = state.getValue(StellarForgeBlock.FORMED);

        List<ForgeStructure.Mismatch> missing = ForgeStructure.findAllMismatches(server, worldPosition);
        if (!missing.isEmpty()) {
            if (formed) server.setBlock(worldPosition, state.setValue(StellarForgeBlock.FORMED, false), 3);
            ForgeStructure.Mismatch first = missing.get(0);
            player.displayClientMessage(Component.translatable("message.constellar.forge_missing",
                    first.expected().getName(),
                    first.pos().getX(), first.pos().getY(), first.pos().getZ()), true);
            if (player instanceof ServerPlayer serverPlayer) {
                sendSummary(serverPlayer, missing);
                GhostHints.start(serverPlayer, worldPosition);
            }
            return;
        }

        if (!formed) {
            server.setBlock(worldPosition, state.setValue(StellarForgeBlock.FORMED, true), 3);
            server.playSound(null, worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);
            burst(server, 60);
            for (int dx = -2; dx <= 2; dx += 4) {
                for (int dz = -2; dz <= 2; dz += 4) {
                    BlockPos top = worldPosition.offset(dx, 4, dz);
                    server.sendParticles(ParticleTypes.END_ROD, top.getX() + 0.5, top.getY() + 0.2, top.getZ() + 0.5,
                            12, 0.2, 0.3, 0.2, 0.02);
                }
            }
            player.displayClientMessage(Component.translatable("message.constellar.forge_formed"), true);
            return;
        }

        tryCraft(server, player);
    }

    /** Lista no chat quanto falta de cada bloco. */
    private static void sendSummary(ServerPlayer player, List<ForgeStructure.Mismatch> missing) {
        Map<Block, Integer> counts = new LinkedHashMap<>();
        for (ForgeStructure.Mismatch m : missing) counts.merge(m.expected(), 1, Integer::sum);

        MutableComponent text = Component.translatable("message.constellar.forge_summary");
        boolean first = true;
        for (Map.Entry<Block, Integer> e : counts.entrySet()) {
            text.append(Component.literal(first ? " " : ", ")
                    .append(Component.literal(e.getValue() + "x "))
                    .append(e.getKey().getName()));
            first = false;
        }
        player.sendSystemMessage(text);
        player.sendSystemMessage(Component.translatable("message.constellar.forge_hint"));
    }

    /** Papel + glifos na forja = Pergaminho de Magia (forma primeiro, depois efeitos e aumentos). */
    private boolean trySpellScroll(ServerLevel server, Player player, List<ItemStack> contents) {
        int papers = 0;
        boolean other = false;
        List<String> glyphs = new ArrayList<>();
        for (ItemStack stack : contents) {
            if (stack.is(Items.PAPER)) papers++;
            else if (stack.getItem() instanceof GlyphItem glyphItem) glyphs.add(glyphItem.glyph().id());
            else other = true;
        }
        if (papers != 1 || other || glyphs.isEmpty()) return false;

        ParsedSpell spell = ParsedSpell.parse(glyphs);
        if (spell == null) {
            player.displayClientMessage(Component.translatable("message.constellar.forge_spell_invalid"), true);
            return true;
        }
        int energyCost = 400 * glyphs.size();
        if (energy.getEnergyStored() < energyCost) {
            player.displayClientMessage(Component.translatable("message.constellar.forge_need_energy",
                    energy.getEnergyStored(), energyCost), true);
            return true;
        }

        energy.consume(energyCost);
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
        itemsChanged();

        ItemStack scroll = new ItemStack(ModItems.SPELL_SCROLL.get());
        scroll.set(ModComponents.SPELL.get(), List.copyOf(glyphs));
        ItemEntity drop = new ItemEntity(server,
                worldPosition.getX() + 0.5, worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5, scroll);
        drop.setDeltaMovement(0, 0.15, 0);
        server.addFreshEntity(drop);

        server.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.5F, 1.2F);
        server.playSound(null, worldPosition, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
        burst(server, 50);
        player.displayClientMessage(Component.translatable("message.constellar.forge_spell_created"), true);
        return true;
    }

    private void tryCraft(ServerLevel server, Player player) {
        List<ItemStack> contents = contents();
        if (trySpellScroll(server, player, contents)) return;
        Registry<ForgeRecipe> registry = server.registryAccess().registryOrThrow(ForgeRecipeRegistry.KEY);

        for (ForgeRecipe recipe : registry) {
            if (!recipe.matches(contents)) continue;

            if (recipe.constellation().isPresent()
                    && !player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS).contains(recipe.constellation().get())) {
                player.displayClientMessage(Component.translatable("message.constellar.forge_need_constellation",
                        Starlight.constellationName(server, recipe.constellation().get())), true);
                return;
            }
            if (energy.getEnergyStored() < recipe.energy()) {
                player.displayClientMessage(Component.translatable("message.constellar.forge_need_energy",
                        energy.getEnergyStored(), recipe.energy()), true);
                return;
            }

            energy.consume(recipe.energy());
            for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
            itemsChanged();

            ItemEntity drop = new ItemEntity(server,
                    worldPosition.getX() + 0.5, worldPosition.getY() + 1.4, worldPosition.getZ() + 0.5,
                    new ItemStack(recipe.result(), recipe.count()));
            drop.setDeltaMovement(0, 0.15, 0);
            server.addFreshEntity(drop);

            server.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.5F, 0.8F);
            server.playSound(null, worldPosition, SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            burst(server, 40);
            player.displayClientMessage(Component.translatable("message.constellar.forge_crafted"), true);
            return;
        }
        player.displayClientMessage(Component.translatable("message.constellar.forge_no_recipe"), true);
    }

    private void burst(ServerLevel server, int count) {
        server.sendParticles(ParticleTypes.ENCHANT,
                worldPosition.getX() + 0.5, worldPosition.getY() + 1.3, worldPosition.getZ() + 0.5,
                count, 0.6, 0.6, 0.6, 0.4);
        server.sendParticles(ParticleTypes.END_ROD,
                worldPosition.getX() + 0.5, worldPosition.getY() + 1.3, worldPosition.getZ() + 0.5,
                count / 2, 0.4, 0.5, 0.4, 0.05);
    }

    // ---------- tick: as lentes das torres captam luz das estrelas ----------
    public static void serverTick(Level level, BlockPos pos, BlockState state, StellarForgeBlockEntity be) {
        boolean formed = state.getValue(StellarForgeBlock.FORMED);

        if (level.getGameTime() % 20 == 0) {
            be.multiplier = Starlight.computeMultiplier(level);
            if (formed && ForgeStructure.findMismatch(level, pos) != null) {
                level.setBlock(pos, state.setValue(StellarForgeBlock.FORMED, false), 3);
                formed = false;
            }
            be.setChanged();
        }

        if (formed && level.dimensionType().hasSkyLight() && Starlight.isNight(level)) {
            int towers = ForgeStructure.countTowersWithSky(level, pos);
            if (towers > 0) {
                be.energy.generate(Math.round(CHARGE_PER_TOWER * towers * be.multiplier));
            }
        }
    }

    // ---------- save / sync ----------
    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        ContainerHelper.saveAllItems(tag, items, registries);
        energy.save(tag);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int i = 0; i < SLOTS; i++) items.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, items, registries);
        energy.load(tag);
    }

    @Override
    public CompoundTag getUpdateTag(HolderLookup.Provider registries) {
        return saveWithoutMetadata(registries);
    }

    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }
}
