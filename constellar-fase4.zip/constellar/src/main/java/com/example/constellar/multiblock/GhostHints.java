package com.example.constellar.multiblock;

import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.tick.ServerTickEvent;
import org.joml.Vector3f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Depois de usar a Varinha Estelar numa forja incompleta, mostra por 20 segundos
 * nuvens azuis nos lugares onde ainda falta um bloco (so o jogador que usou ve).
 */
public final class GhostHints {
    private record Hint(ResourceKey<Level> dimension, BlockPos forge, long expires) {}

    private static final Map<UUID, Hint> HINTS = new HashMap<>();
    private static final DustParticleOptions BLUE =
            new DustParticleOptions(new Vector3f(0.25F, 0.55F, 1.0F), 1.5F);
    private static final double MAX_DISTANCE_SQR = 48.0 * 48.0;

    private GhostHints() {}

    public static void start(ServerPlayer player, BlockPos forge) {
        ServerLevel level = player.serverLevel();
        HINTS.put(player.getUUID(), new Hint(level.dimension(), forge, level.getGameTime() + 400L));
    }

    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        if (HINTS.isEmpty() || server.getTickCount() % 8 != 0) return;

        Iterator<Map.Entry<UUID, Hint>> it = HINTS.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Hint> entry = it.next();
            Hint hint = entry.getValue();
            ServerPlayer player = server.getPlayerList().getPlayer(entry.getKey());
            if (player == null) {
                it.remove();
                continue;
            }
            ServerLevel level = player.serverLevel();
            if (level.dimension() != hint.dimension()
                    || level.getGameTime() > hint.expires()
                    || !level.getBlockState(hint.forge()).is(ModBlocks.STELLAR_FORGE.get())) {
                it.remove();
                continue;
            }
            List<ForgeStructure.Mismatch> missing = ForgeStructure.findAllMismatches(level, hint.forge());
            if (missing.isEmpty()) {
                it.remove();
                continue;
            }
            for (ForgeStructure.Mismatch m : missing) {
                Vec3 center = Vec3.atCenterOf(m.pos());
                if (player.distanceToSqr(center) > MAX_DISTANCE_SQR) continue;
                level.sendParticles(player, BLUE, true, center.x, center.y, center.z,
                        18, 0.3, 0.3, 0.3, 0.0);
            }
        }
    }
}
