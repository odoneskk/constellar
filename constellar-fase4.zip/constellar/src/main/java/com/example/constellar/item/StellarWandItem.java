package com.example.constellar.item;

import com.example.constellar.block.StellarForgeBlockEntity;
import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/**
 * Varinha Estelar: botao direito na Forja Estelar (ou no Cristal do Void em cima dela)
 * forma a estrutura; com a forja ativa e itens colocados, executa a receita.
 */
public class StellarWandItem extends Item {
    public StellarWandItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);

        BlockPos forgePos = null;
        if (state.is(ModBlocks.STELLAR_FORGE.get())) {
            forgePos = pos;
        } else if (state.is(ModBlocks.VOID_CRYSTAL.get())
                && level.getBlockState(pos.below()).is(ModBlocks.STELLAR_FORGE.get())) {
            forgePos = pos.below();
        }
        if (forgePos == null) return InteractionResult.PASS;
        if (level.isClientSide) return InteractionResult.SUCCESS;

        if (context.getPlayer() != null && level.getBlockEntity(forgePos) instanceof StellarForgeBlockEntity forge) {
            forge.activate(context.getPlayer());
        }
        return InteractionResult.CONSUME;
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
