package com.example.constellar.block;

import com.example.constellar.energy.FEStorage;
import com.example.constellar.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.neoforge.energy.IEnergyStorage;

public class StellarBatteryBlockEntity extends BlockEntity {
    private final FEStorage energy = new FEStorage(2_000_000, 20_000, 20_000, this::setChanged);

    public StellarBatteryBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STELLAR_BATTERY.get(), pos, state);
    }

    public IEnergyStorage getEnergy() {
        return energy;
    }

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        energy.save(tag);
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        energy.load(tag);
    }
}
