package com.example.constellar.client;

import com.example.constellar.Constellar;
import com.example.constellar.constellation.Constellation;
import com.example.constellar.constellation.ConstellationRegistry;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.BufferUploader;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.MeshData;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;

/**
 * Desenha no ceu noturno as constelacoes que o jogador ja descobriu:
 * estrelas brilhantes ligadas por linhas, na cor da constelacao, girando junto com o ceu.
 */
@EventBusSubscriber(modid = Constellar.MODID, value = Dist.CLIENT)
public final class SkyConstellationRenderer {
    private static final float RADIUS = 95.0F;
    private static final float SIZE = 42.0F;

    private SkyConstellationRenderer() {}

    private record Entry(ResourceLocation id, Constellation constellation) {}

    @SubscribeEvent
    public static void onRenderLevelStage(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_SKY) return;

        Minecraft mc = Minecraft.getInstance();
        ClientLevel level = mc.level;
        if (level == null || level.dimension() != Level.OVERWORLD) return;

        List<ResourceLocation> discovered = ClientConstellationData.get();
        if (discovered.isEmpty()) return;

        float visibility = level.getStarBrightness(0.0F) * (1.0F - level.getRainLevel(0.0F));
        float alpha = Math.min(1.0F, visibility * 2.0F);
        if (alpha <= 0.02F) return;

        Registry<Constellation> registry = level.registryAccess().registry(ConstellationRegistry.KEY).orElse(null);
        if (registry == null) return;

        List<Entry> entries = new ArrayList<>();
        for (ResourceLocation id : discovered) {
            Constellation c = registry.get(id);
            if (c != null) entries.add(new Entry(id, c));
        }
        if (entries.isEmpty()) return;

        // Mesma rotacao que o ceu do jogo usa para as estrelas.
        Matrix4f matrix = new Matrix4f()
                .rotation(event.getCamera().rotation().conjugate(new Quaternionf()))
                .rotateY((float) Math.toRadians(-90.0))
                .rotateX(level.getTimeOfDay(0.0F) * (float) (Math.PI * 2.0));

        RenderSystem.setShader(GameRenderer::getPositionColorShader);
        RenderSystem.enableBlend();
        RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        RenderSystem.depthMask(false);
        RenderSystem.disableCull();

        BufferBuilder buffer = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_COLOR);
        long time = level.getGameTime();
        for (Entry entry : entries) {
            drawConstellation(buffer, matrix, entry, alpha, time);
        }
        MeshData mesh = buffer.build();
        if (mesh != null) {
            BufferUploader.drawWithShader(mesh);
        }

        RenderSystem.enableCull();
        RenderSystem.depthMask(true);
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
    }

    private static void drawConstellation(BufferBuilder buf, Matrix4f m, Entry entry, float alpha, long time) {
        Constellation c = entry.constellation();
        if (c.stars().isEmpty()) return;

        // Posicao fixa no ceu, sorteada a partir do id (o lado "de baixo" fica sobre a cabeca a meia-noite).
        RandomSource rnd = RandomSource.create(entry.id().toString().hashCode() * 31L + 17L);
        float azimuth = rnd.nextFloat() * Mth.TWO_PI;
        float pitch = (float) Math.toRadians(25.0 + rnd.nextFloat() * 55.0);
        Vector3f forward = new Vector3f(
                Mth.cos(pitch) * Mth.cos(azimuth),
                -Mth.sin(pitch),
                Mth.cos(pitch) * Mth.sin(azimuth));
        Vector3f right = forward.cross(new Vector3f(0, 1, 0), new Vector3f());
        if (right.lengthSquared() < 1.0E-4F) right.set(1, 0, 0);
        right.normalize();
        Vector3f up = right.cross(forward, new Vector3f()).normalize();

        float cr = ((c.color() >> 16) & 255) / 255.0F;
        float cg = ((c.color() >> 8) & 255) / 255.0F;
        float cb = (c.color() & 255) / 255.0F;

        List<Vector3f> points = new ArrayList<>();
        for (Constellation.Star s : c.stars()) {
            float sx = (s.x() - 8) / 16.0F * SIZE;
            float sy = -(s.y() - 8) / 16.0F * SIZE;
            Vector3f p = new Vector3f(forward).mul(RADIUS)
                    .add(new Vector3f(right).mul(sx))
                    .add(new Vector3f(up).mul(sy));
            p.normalize(RADIUS);
            points.add(p);
        }

        // Linhas
        if (c.links().isEmpty()) {
            for (int i = 0; i + 1 < points.size(); i++) {
                line(buf, m, points.get(i), points.get(i + 1), cr, cg, cb, alpha * 0.45F);
            }
        } else {
            for (List<Integer> link : c.links()) {
                if (link.size() < 2) continue;
                int a = link.get(0);
                int b = link.get(1);
                if (a < 0 || b < 0 || a >= points.size() || b >= points.size()) continue;
                line(buf, m, points.get(a), points.get(b), cr, cg, cb, alpha * 0.45F);
            }
        }

        // Estrelas (halo + nucleo) com leve cintilacao
        for (int i = 0; i < points.size(); i++) {
            float twinkle = 0.8F + 0.2F * Mth.sin(time * 0.15F + i * 1.7F);
            star(buf, m, points.get(i), 3.4F, cr, cg, cb, alpha * 0.20F * twinkle);
            star(buf, m, points.get(i), 1.5F, 1.0F, 1.0F, 1.0F, alpha * twinkle);
        }
    }

    private static void line(BufferBuilder buf, Matrix4f m, Vector3f a, Vector3f b, float r, float g, float bl, float al) {
        Vector3f dir = b.sub(a, new Vector3f());
        Vector3f mid = a.add(b, new Vector3f()).mul(0.5F);
        Vector3f side = dir.cross(mid, new Vector3f());
        if (side.lengthSquared() < 1.0E-6F) return;
        side.normalize(0.2F);
        quad(buf, m,
                a.add(side, new Vector3f()), b.add(side, new Vector3f()),
                b.sub(side, new Vector3f()), a.sub(side, new Vector3f()),
                r, g, bl, al);
    }

    private static void star(BufferBuilder buf, Matrix4f m, Vector3f p, float size, float r, float g, float bl, float al) {
        Vector3f n = p.normalize(new Vector3f());
        Vector3f right = n.cross(new Vector3f(0, 1, 0), new Vector3f());
        if (right.lengthSquared() < 1.0E-4F) right.set(1, 0, 0);
        right.normalize(size);
        Vector3f up = right.cross(n, new Vector3f()).normalize(size);
        quad(buf, m,
                p.sub(right, new Vector3f()).sub(up),
                p.add(right, new Vector3f()).sub(up),
                p.add(right, new Vector3f()).add(up),
                p.sub(right, new Vector3f()).add(up),
                r, g, bl, al);
    }

    private static void quad(BufferBuilder buf, Matrix4f m, Vector3f a, Vector3f b, Vector3f c, Vector3f d,
                             float r, float g, float bl, float al) {
        vertex(buf, m, a, r, g, bl, al);
        vertex(buf, m, b, r, g, bl, al);
        vertex(buf, m, c, r, g, bl, al);
        vertex(buf, m, d, r, g, bl, al);
    }

    private static void vertex(BufferBuilder buf, Matrix4f m, Vector3f p, float r, float g, float b, float a) {
        buf.addVertex(m, p.x, p.y, p.z).setColor(r, g, b, a);
    }
}
