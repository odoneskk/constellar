package com.example.constellar.util;

import com.example.constellar.constellation.Constellation;
import com.example.constellar.constellation.ConstellationRegistry;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;

public final class Starlight {
    private Starlight() {}

    public static boolean isNight(Level level) {
        long t = level.getDayTime() % 24000L;
        return t >= 13000L && t < 23000L;
    }

    /** Maior bonus entre as constelacoes que favorecem a fase atual da lua. */
    public static float computeMultiplier(Level level) {
        int phase = level.getMoonPhase();
        float best = 1.0f;
        for (Constellation c : level.registryAccess().registryOrThrow(ConstellationRegistry.KEY)) {
            if (c.preferredMoonPhase() == phase) {
                best = Math.max(best, c.fdBonus());
            }
        }
        return best;
    }

    /** Nome legivel de uma constelacao (ou o proprio id se ela nao existir). */
    public static Component constellationName(Level level, ResourceLocation id) {
        Constellation c = level.registryAccess().registryOrThrow(ConstellationRegistry.KEY).get(id);
        return Component.literal(c != null ? c.name() : id.toString());
    }
}
