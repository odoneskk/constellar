package com.example.constellar.energy;

import net.minecraft.nbt.CompoundTag;
import net.neoforged.neoforge.energy.IEnergyStorage;
import org.jetbrains.annotations.Nullable;

/** Armazenamento de FE (Forge Energy) padrao, compativel com cabos e maquinas de outros mods. */
public class FEStorage implements IEnergyStorage {
    private int energy;
    private final int capacity;
    private final int maxReceive;
    private final int maxExtract;
    @Nullable
    private final Runnable onChange;

    public FEStorage(int capacity, int maxReceive, int maxExtract, @Nullable Runnable onChange) {
        this.capacity = capacity;
        this.maxReceive = maxReceive;
        this.maxExtract = maxExtract;
        this.onChange = onChange;
    }

    @Override
    public int receiveEnergy(int toReceive, boolean simulate) {
        if (!canReceive() || toReceive <= 0) return 0;
        int received = Math.min(capacity - energy, Math.min(maxReceive, toReceive));
        if (!simulate && received > 0) {
            energy += received;
            changed();
        }
        return received;
    }

    @Override
    public int extractEnergy(int toExtract, boolean simulate) {
        if (!canExtract() || toExtract <= 0) return 0;
        int extracted = Math.min(energy, Math.min(maxExtract, toExtract));
        if (!simulate && extracted > 0) {
            energy -= extracted;
            changed();
        }
        return extracted;
    }

    @Override
    public int getEnergyStored() {
        return energy;
    }

    @Override
    public int getMaxEnergyStored() {
        return capacity;
    }

    @Override
    public boolean canExtract() {
        return maxExtract > 0;
    }

    @Override
    public boolean canReceive() {
        return maxReceive > 0;
    }

    /** Uso interno (geradores): adiciona energia ignorando o limite de entrada. */
    public void generate(int amount) {
        if (amount <= 0) return;
        energy = Math.min(capacity, energy + amount);
    }

    /** Uso interno (receitas): gasta energia se houver o bastante. */
    public boolean consume(int amount) {
        if (amount > energy) return false;
        energy -= amount;
        changed();
        return true;
    }

    private void changed() {
        if (onChange != null) onChange.run();
    }

    public void save(CompoundTag tag) {
        tag.putInt("energy", energy);
    }

    public void load(CompoundTag tag) {
        energy = Math.max(0, Math.min(capacity, tag.getInt("energy")));
    }
}
