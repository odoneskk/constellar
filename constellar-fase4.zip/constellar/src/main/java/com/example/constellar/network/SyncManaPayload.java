package com.example.constellar.network;

import com.example.constellar.Constellar;
import com.example.constellar.client.ClientManaData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/** Servidor -> cliente: mana atual e maxima (para a barra na tela). */
public record SyncManaPayload(int mana, int max) implements CustomPacketPayload {
    public static final Type<SyncManaPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Constellar.MODID, "sync_mana"));

    public static final StreamCodec<ByteBuf, SyncManaPayload> STREAM_CODEC = StreamCodec.composite(
            ByteBufCodecs.VAR_INT, SyncManaPayload::mana,
            ByteBufCodecs.VAR_INT, SyncManaPayload::max,
            SyncManaPayload::new);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SyncManaPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientManaData.set(payload.mana(), payload.max()));
    }
}
