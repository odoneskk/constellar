package com.example.constellar.entity;

import com.example.constellar.spell.ParsedSpell;
import com.example.constellar.spell.SpellCaster;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

/** Projetil magico: viaja em linha reta com rastro de particulas e aplica a magia ao atingir algo. */
public class StarBoltEntity extends Projectile {
    @Nullable
    private ParsedSpell spell;
    private int age;

    public StarBoltEntity(EntityType<? extends StarBoltEntity> type, Level level) {
        super(type, level);
    }

    public void configure(ParsedSpell spell) {
        this.spell = spell;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
    }

    @Override
    public void tick() {
        super.tick();
        if (!(level() instanceof ServerLevel server)) return;
        if (spell == null || ++age > 70) {
            discard();
            return;
        }

        HitResult hit = ProjectileUtil.getHitResultOnMoveVector(this, this::canHitEntity);
        if (hit.getType() != HitResult.Type.MISS) {
            impact(server, hit);
            return;
        }

        Vec3 next = position().add(getDeltaMovement());
        setPos(next.x, next.y, next.z);

        int rgb = spell.color();
        Vector3f color = new Vector3f(((rgb >> 16) & 255) / 255.0F, ((rgb >> 8) & 255) / 255.0F, (rgb & 255) / 255.0F);
        server.sendParticles(new DustParticleOptions(color, 1.4F), getX(), getY(), getZ(), 3, 0.06, 0.06, 0.06, 0.0);
        server.sendParticles(ParticleTypes.END_ROD, getX(), getY(), getZ(), 1, 0.02, 0.02, 0.02, 0.0);
    }

    private void impact(ServerLevel server, HitResult hit) {
        Entity owner = getOwner();
        Vec3 pos = hit.getLocation();
        Entity target = null;
        if (hit instanceof EntityHitResult entityHit) {
            target = entityHit.getEntity();
        } else {
            Vec3 back = getDeltaMovement();
            if (back.lengthSqr() > 1.0E-4) pos = pos.subtract(back.normalize().scale(0.3));
        }
        if (owner instanceof ServerPlayer player && spell != null) {
            SpellCaster.resolve(server, player, spell, pos, target);
        }
        discard();
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
    }
}
