package com.example.constellar.item;

import com.example.constellar.glyph.Glyph;
import com.example.constellar.mana.ManaManager;
import com.example.constellar.registry.ModComponents;
import com.example.constellar.spell.ParsedSpell;
import com.example.constellar.spell.SpellCaster;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import java.util.List;
import java.util.Optional;

/** Pergaminho de Magia: guarda uma magia montada na forja. Botao direito lanca (gasta mana). */
public class SpellScrollItem extends Item {
    public SpellScrollItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!(level instanceof ServerLevel server) || !(player instanceof ServerPlayer serverPlayer)) {
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        List<String> ids = stack.get(ModComponents.SPELL.get());
        ParsedSpell spell = ids == null ? null : ParsedSpell.parse(ids);
        if (spell == null) {
            player.displayClientMessage(Component.translatable("message.constellar.scroll_empty"), true);
            return InteractionResultHolder.fail(stack);
        }
        if (!ManaManager.consume(serverPlayer, spell.cost())) {
            player.displayClientMessage(Component.translatable("message.constellar.mana_insufficient",
                    ManaManager.get(serverPlayer), spell.cost()), true);
            return InteractionResultHolder.fail(stack);
        }

        SpellCaster.cast(server, serverPlayer, spell);
        player.getCooldowns().addCooldown(this, 10 + spell.cost() / 2);
        return InteractionResultHolder.sidedSuccess(stack, false);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return stack.get(ModComponents.SPELL.get()) != null;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        List<String> ids = stack.get(ModComponents.SPELL.get());
        ParsedSpell spell = ids == null ? null : ParsedSpell.parse(ids);
        if (spell == null) {
            tooltip.add(Component.translatable("tooltip.constellar.scroll_blank").withStyle(ChatFormatting.GRAY));
            return;
        }
        MutableComponent line = Component.empty();
        boolean first = true;
        for (String id : ids) {
            Optional<Glyph> glyph = Glyph.byId(id);
            if (glyph.isEmpty()) continue;
            if (!first) line.append(Component.literal(" > ").withStyle(ChatFormatting.DARK_GRAY));
            line.append(Component.translatable("item.constellar.glyph_" + id)
                    .withStyle(s -> s.withColor(glyph.get().color())));
            first = false;
        }
        tooltip.add(line);
        tooltip.add(Component.translatable("tooltip.constellar.mana_cost", spell.cost()).withStyle(ChatFormatting.BLUE));
    }
}
