package com.example.constellar.item;

import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

/** Mostra a energia (FE) armazenada no bloco clicado. */
public class EnergyReaderItem extends Item {
    public EnergyReaderItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        var level = context.getLevel();
        Player player = context.getPlayer();
        if (level.isClientSide || player == null) return InteractionResult.SUCCESS;

        IEnergyStorage energy = level.getCapability(Capabilities.EnergyStorage.BLOCK,
                context.getClickedPos(), context.getClickedFace());
        if (energy == null) {
            player.displayClientMessage(Component.translatable("message.constellar.no_energy"), true);
        } else {
            player.displayClientMessage(Component.translatable("message.constellar.energy_amount",
                    energy.getEnergyStored(), energy.getMaxEnergyStored()), true);
        }
        return InteractionResult.CONSUME;
    }
}
