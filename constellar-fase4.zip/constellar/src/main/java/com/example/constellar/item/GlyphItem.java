package com.example.constellar.item;

import com.example.constellar.glyph.Glyph;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/** Glifo: peca para montar magias na Forja Estelar. */
public class GlyphItem extends Item {
    private final Glyph glyph;

    public GlyphItem(Properties properties, Glyph glyph) {
        super(properties);
        this.glyph = glyph;
    }

    public Glyph glyph() {
        return glyph;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.constellar.glyph_type." + glyph.type().name().toLowerCase())
                .withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.translatable("tooltip.constellar.glyph_desc." + glyph.id()).withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.translatable("tooltip.constellar.mana_cost", glyph.cost()).withStyle(ChatFormatting.BLUE));
    }
}
