package com.example.constellar.client;

import com.example.constellar.block.StellarForgeBlockEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/** Desenha os itens colocados na forja girando em volta do Cristal do Void. */
public class ForgeRenderer implements BlockEntityRenderer<StellarForgeBlockEntity> {
    public ForgeRenderer(BlockEntityRendererProvider.Context context) {}

    @Override
    public void render(StellarForgeBlockEntity be, float partialTick, PoseStack pose,
                       MultiBufferSource buffer, int light, int overlay) {
        if (be.getLevel() == null) return;
        List<ItemStack> items = be.contents();
        if (items.isEmpty()) return;

        float time = be.getLevel().getGameTime() + partialTick;
        int n = items.size();
        for (int i = 0; i < n; i++) {
            double angle = time * 0.05 + i * (Math.PI * 2.0 / n);
            pose.pushPose();
            pose.translate(0.5 + Math.cos(angle) * 0.62,
                    1.5 + Math.sin(time * 0.1 + i) * 0.05,
                    0.5 + Math.sin(angle) * 0.62);
            pose.mulPose(Axis.YP.rotationDegrees(time * 2.0F));
            pose.scale(0.4F, 0.4F, 0.4F);
            Minecraft.getInstance().getItemRenderer().renderStatic(items.get(i), ItemDisplayContext.FIXED,
                    LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, pose, buffer, be.getLevel(), i);
            pose.popPose();
        }
    }
}
