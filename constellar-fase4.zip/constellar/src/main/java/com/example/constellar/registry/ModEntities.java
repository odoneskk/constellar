package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.example.constellar.entity.StarBoltEntity;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, Constellar.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<StarBoltEntity>> STAR_BOLT =
            ENTITIES.register("star_bolt", () -> EntityType.Builder.<StarBoltEntity>of(StarBoltEntity::new, MobCategory.MISC)
                    .sized(0.3F, 0.3F)
                    .clientTrackingRange(8)
                    .updateInterval(2)
                    .build("star_bolt"));

    private ModEntities() {}
}
