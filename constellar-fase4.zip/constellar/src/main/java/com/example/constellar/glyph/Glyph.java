package com.example.constellar.glyph;

import java.util.Optional;

/**
 * Glifos para montar magias (estilo Ars Nouveau):
 * uma FORMA (como a magia e lancada), um ou mais EFEITOS e AUMENTOS opcionais.
 */
public enum Glyph {
    // ---- formas ----
    PROJECTILE(Type.FORM, "projectile", 10, 0x6EC8FF),
    BEAM(Type.FORM, "beam", 15, 0x9AF2FF),
    SELF(Type.FORM, "self", 5, 0xFFFFFF),
    AREA(Type.FORM, "area", 20, 0xB38CFF),
    // ---- efeitos ----
    DAMAGE(Type.EFFECT, "damage", 20, 0xFF5050),
    FIRE(Type.EFFECT, "fire", 15, 0xFF9020),
    LIGHTNING(Type.EFFECT, "lightning", 35, 0xF0F060),
    PULL(Type.EFFECT, "pull", 20, 0xA070FF),
    PUSH(Type.EFFECT, "push", 10, 0xC0D0FF),
    HEAL(Type.EFFECT, "heal", 30, 0x60FF90),
    BLINK(Type.EFFECT, "blink", 25, 0xD060FF),
    FREEZE(Type.EFFECT, "freeze", 15, 0x80E0FF),
    EXPLODE(Type.EFFECT, "explode", 40, 0xFFB040),
    STARFALL(Type.EFFECT, "starfall", 50, 0xFFF0A0),
    BLACK_HOLE(Type.EFFECT, "black_hole", 60, 0x6020C0),
    // ---- aumentos ----
    AMPLIFY(Type.AUGMENT, "amplify", 15, 0xFFD060),
    EXTEND(Type.AUGMENT, "extend", 10, 0xFFD060),
    MULTIPLY(Type.AUGMENT, "multiply", 25, 0xFFD060),
    CHAIN(Type.AUGMENT, "chain", 20, 0xFFD060);

    public enum Type { FORM, EFFECT, AUGMENT }

    private final Type type;
    private final String id;
    private final int cost;
    private final int color;

    Glyph(Type type, String id, int cost, int color) {
        this.type = type;
        this.id = id;
        this.cost = cost;
        this.color = color;
    }

    public Type type() { return type; }
    public String id() { return id; }
    /** Custo de mana. */
    public int cost() { return cost; }
    /** Cor RGB das particulas. */
    public int color() { return color; }

    public static Optional<Glyph> byId(String id) {
        for (Glyph g : values()) {
            if (g.id.equals(id)) return Optional.of(g);
        }
        return Optional.empty();
    }
}
