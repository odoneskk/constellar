package com.example.constellar.block;

import com.example.constellar.constellation.Constellation;
import com.example.constellar.constellation.ConstellationRegistry;
import com.example.constellar.network.SyncConstellationsPayload;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.registry.ModItems;
import com.example.constellar.util.Starlight;
import com.mojang.serialization.MapCodec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.Style;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.neoforged.neoforge.network.PacketDistributor;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Telescopio (bloco 3D): clique direito, de noite e com ceu aberto, para ler as estrelas.
 * Cada leitura descobre uma constelacao nova, que passa a aparecer desenhada no ceu.
 */
public class TelescopeBlock extends Block {
    public static final MapCodec<TelescopeBlock> CODEC = simpleCodec(TelescopeBlock::new);
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;
    private static final VoxelShape SHAPE = Block.box(3, 0, 3, 13, 16, 13);

    public TelescopeBlock(Properties properties) {
        super(properties);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected MapCodec<? extends Block> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext context) {
        return defaultBlockState().setValue(FACING, context.getHorizontalDirection());
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
        return SHAPE;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hitResult) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        if (!(player instanceof ServerPlayer serverPlayer)) return InteractionResult.CONSUME;

        if (serverPlayer.getCooldowns().isOnCooldown(ModItems.TELESCOPE.get())) {
            return InteractionResult.CONSUME;
        }
        if (!level.dimensionType().hasSkyLight() || !Starlight.isNight(level) || !level.canSeeSky(pos.above())) {
            player.displayClientMessage(Component.translatable("message.constellar.cannot_observe"), true);
            return InteractionResult.CONSUME;
        }

        List<ResourceLocation> known = serverPlayer.getData(ModAttachments.DISCOVERED_CONSTELLATIONS);
        var registry = level.registryAccess().registryOrThrow(ConstellationRegistry.KEY);

        List<Map.Entry<ResourceLocation, Constellation>> undiscovered = new ArrayList<>();
        for (var entry : registry.entrySet()) {
            ResourceLocation id = entry.getKey().location();
            if (!known.contains(id)) {
                undiscovered.add(Map.entry(id, entry.getValue()));
            }
        }
        if (undiscovered.isEmpty()) {
            player.displayClientMessage(Component.translatable("message.constellar.nothing_new"), true);
            return InteractionResult.CONSUME;
        }

        var found = undiscovered.get(level.random.nextInt(undiscovered.size()));
        List<ResourceLocation> updated = new ArrayList<>(known);
        updated.add(found.getKey());
        serverPlayer.setData(ModAttachments.DISCOVERED_CONSTELLATIONS, List.copyOf(updated));
        PacketDistributor.sendToPlayer(serverPlayer, new SyncConstellationsPayload(List.copyOf(updated)));

        Component name = Component.literal(found.getValue().name())
                .withStyle(Style.EMPTY.withColor(found.getValue().color()));
        serverPlayer.sendSystemMessage(Component.translatable("message.constellar.discovered", name));
        serverPlayer.getCooldowns().addCooldown(ModItems.TELESCOPE.get(), 100);
        return InteractionResult.CONSUME;
    }
}
