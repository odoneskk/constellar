package com.example.constellar.client;

/** Mana do jogador local (enviada pelo servidor). Sem classes de cliente. */
public final class ClientManaData {
    private static volatile int mana;
    private static volatile int max;

    private ClientManaData() {}

    public static int mana() { return mana; }
    public static int max() { return max; }

    public static void set(int mana, int max) {
        ClientManaData.mana = mana;
        ClientManaData.max = max;
    }
}
