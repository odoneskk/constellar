package com.example.constellar.network;

import com.example.constellar.Constellar;
import com.example.constellar.client.ClientConstellationData;
import io.netty.buffer.ByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.network.handling.IPayloadContext;

import java.util.List;

/** Servidor -> cliente: lista de constelacoes descobertas (para desenhar no ceu). */
public record SyncConstellationsPayload(List<ResourceLocation> ids) implements CustomPacketPayload {
    public static final Type<SyncConstellationsPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(Constellar.MODID, "sync_constellations"));

    public static final StreamCodec<ByteBuf, SyncConstellationsPayload> STREAM_CODEC =
            ResourceLocation.STREAM_CODEC.apply(ByteBufCodecs.list())
                    .map(SyncConstellationsPayload::new, SyncConstellationsPayload::ids);

    @Override
    public Type<? extends CustomPacketPayload> type() {
        return TYPE;
    }

    public static void handle(SyncConstellationsPayload payload, IPayloadContext context) {
        context.enqueueWork(() -> ClientConstellationData.set(payload.ids()));
    }
}
