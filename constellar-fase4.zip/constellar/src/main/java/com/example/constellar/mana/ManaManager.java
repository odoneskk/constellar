package com.example.constellar.mana;

import com.example.constellar.network.SyncManaPayload;
import com.example.constellar.registry.ModAttachments;
import com.example.constellar.util.Starlight;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

/**
 * Mana do jogador: o maximo cresce com cada constelacao descoberta,
 * e ela recarrega mais rapido sob o ceu noturno.
 */
public final class ManaManager {
    private ManaManager() {}

    public static int max(ServerPlayer player) {
        return 100 + 20 * player.getData(ModAttachments.DISCOVERED_CONSTELLATIONS).size();
    }

    public static int get(ServerPlayer player) {
        return Math.max(0, Math.min(max(player), player.getData(ModAttachments.MANA)));
    }

    public static boolean consume(ServerPlayer player, int amount) {
        int current = get(player);
        if (current < amount) return false;
        player.setData(ModAttachments.MANA, current - amount);
        sync(player);
        return true;
    }

    public static void sync(ServerPlayer player) {
        PacketDistributor.sendToPlayer(player, new SyncManaPayload(get(player), max(player)));
    }

    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer player)) return;
        if (player.tickCount % 10 != 0) return;

        int max = max(player);
        int current = get(player);
        boolean night = player.level().dimensionType().hasSkyLight() && Starlight.isNight(player.level())
                && player.level().canSeeSky(player.blockPosition());
        int regen = night ? 5 : 2;
        int next = Math.min(max, current + regen);
        if (next != current) {
            player.setData(ModAttachments.MANA, next);
        }
        sync(player);
    }
}
