package com.example.constellar.spell;

import com.example.constellar.glyph.Glyph;
import com.example.constellar.entity.StarBoltEntity;
import com.example.constellar.registry.ModEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ProjectileUtil;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Executa magias montadas com glifos: forma + efeitos + aumentos. */
public final class SpellCaster {
    private static final double BEAM_RANGE = 28.0;

    private SpellCaster() {}

    // =====================================================================
    //  LANCAR
    // =====================================================================
    public static void cast(ServerLevel level, ServerPlayer player, ParsedSpell spell) {
        Vec3 look = player.getLookAngle();
        switch (spell.form()) {
            case PROJECTILE -> {
                int n = spell.multiply() ? 3 : 1;
                for (int i = 0; i < n; i++) {
                    Vec3 dir = spread(look, i, n);
                    StarBoltEntity bolt = new StarBoltEntity(ModEntities.STAR_BOLT.get(), level);
                    bolt.setOwner(player);
                    bolt.configure(spell);
                    Vec3 origin = player.getEyePosition().add(dir.scale(0.8));
                    bolt.setPos(origin.x, origin.y - 0.15, origin.z);
                    bolt.setDeltaMovement(dir.scale(1.5));
                    level.addFreshEntity(bolt);
                }
                level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL,
                        SoundSource.PLAYERS, 1.0F, 1.3F);
            }
            case BEAM -> {
                int n = spell.multiply() ? 3 : 1;
                for (int i = 0; i < n; i++) {
                    beam(level, player, spell, spread(look, i, n));
                }
                level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME,
                        SoundSource.PLAYERS, 1.4F, 0.7F);
            }
            case SELF -> {
                resolve(level, player, spell, player.position().add(0, 1.0, 0), null);
                level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL,
                        SoundSource.PLAYERS, 0.8F, 1.6F);
            }
            case AREA -> {
                Vec3 center = player.position().add(0, 0.5, 0);
                double radius = 6.0 * spell.range();
                for (int i = 0; i < 40; i++) {
                    double a = i * (Math.PI * 2.0 / 40.0);
                    dust(level, spell.color(), center.x + Math.cos(a) * radius, center.y, center.z + Math.sin(a) * radius,
                            2, 0.05);
                }
                resolve(level, player, spell, center, null);
                level.playSound(null, player.blockPosition(), SoundEvents.ILLUSIONER_CAST_SPELL,
                        SoundSource.PLAYERS, 1.0F, 0.9F);
            }
            default -> { }
        }
    }

    private static Vec3 spread(Vec3 look, int index, int count) {
        double degrees = (index - (count - 1) / 2.0) * 9.0;
        return look.yRot((float) Math.toRadians(-degrees));
    }

    private static void beam(ServerLevel level, ServerPlayer player, ParsedSpell spell, Vec3 dir) {
        double range = BEAM_RANGE * spell.range();
        Vec3 start = player.getEyePosition();
        Vec3 end = start.add(dir.scale(range));

        BlockHitResult blockHit = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, player));
        boolean hitBlock = blockHit.getType() != HitResult.Type.MISS;
        if (hitBlock) end = blockHit.getLocation();

        AABB box = player.getBoundingBox().expandTowards(end.subtract(start)).inflate(1.0);
        EntityHitResult entityHit = ProjectileUtil.getEntityHitResult(player, start, end, box,
                e -> e instanceof LivingEntity && !e.isSpectator() && e.isPickable(), range * range);
        Entity hitEntity = null;
        if (entityHit != null) {
            end = entityHit.getLocation();
            hitEntity = entityHit.getEntity();
            hitBlock = false;
        }

        Vec3 path = end.subtract(start);
        double length = path.length();
        Vec3 unit = length > 0.001 ? path.normalize() : dir;
        for (double d = 0.8; d < length; d += 0.35) {
            Vec3 p = start.add(unit.scale(d));
            dust(level, spell.color(), p.x, p.y - 0.1, p.z, 1, 0.0);
            if (((int) (d * 10)) % 5 == 0) {
                level.sendParticles(ParticleTypes.END_ROD, p.x, p.y - 0.1, p.z, 1, 0.03, 0.03, 0.03, 0.0);
            }
        }
        Vec3 impact = (hitBlock) ? end.subtract(unit.scale(0.3)) : end;
        resolve(level, player, spell, impact, hitEntity);
    }

    // =====================================================================
    //  RESOLVER (aplica os efeitos no ponto de impacto / alvos)
    // =====================================================================
    public static void resolve(ServerLevel level, ServerPlayer caster, ParsedSpell spell, Vec3 pos, @Nullable Entity hit) {
        Glyph form = spell.form();
        List<LivingEntity> targets = new ArrayList<>();

        if (form == Glyph.SELF) {
            targets.add(caster);
        } else if (form == Glyph.AREA) {
            double r = 6.0 * spell.range();
            targets.addAll(level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(r),
                    e -> e.isAlive() && !e.isSpectator() && e.position().distanceTo(pos) <= r));
        } else if (hit instanceof LivingEntity living) {
            targets.add(living);
        }

        if (spell.chain() && !targets.isEmpty() && (form == Glyph.PROJECTILE || form == Glyph.BEAM)) {
            LivingEntity first = targets.get(0);
            double chainRange = 7.0 * spell.range();
            List<LivingEntity> near = new ArrayList<>(level.getEntitiesOfClass(LivingEntity.class,
                    first.getBoundingBox().inflate(chainRange),
                    e -> e != caster && e != first && e.isAlive() && !e.isSpectator()
                            && e.distanceTo(first) <= chainRange));
            near.sort(Comparator.comparingDouble(e -> e.distanceToSqr(first)));
            Vec3 from = first.position().add(0, first.getBbHeight() / 2, 0);
            for (int i = 0; i < Math.min(3, near.size()); i++) {
                LivingEntity next = near.get(i);
                targets.add(next);
                Vec3 to = next.position().add(0, next.getBbHeight() / 2, 0);
                Vec3 seg = to.subtract(from);
                double len = seg.length();
                for (double d = 0; d < len; d += 0.4) {
                    Vec3 p = from.add(seg.scale(d / len));
                    level.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.x, p.y, p.z, 1, 0.02, 0.02, 0.02, 0.0);
                }
                from = to;
            }
        }

        for (Glyph effect : spell.effects()) {
            apply(level, caster, spell, effect, pos, targets);
        }
    }

    private static DamageSource magic(ServerLevel level, ServerPlayer caster) {
        return level.damageSources().indirectMagic(caster, caster);
    }

    private static void apply(ServerLevel level, ServerPlayer caster, ParsedSpell spell, Glyph effect,
                              Vec3 pos, List<LivingEntity> targets) {
        float power = spell.power();
        float range = spell.range();
        List<LivingEntity> foes = new ArrayList<>();
        for (LivingEntity t : targets) if (t != caster) foes.add(t);

        switch (effect) {
            case DAMAGE -> {
                for (LivingEntity t : foes) {
                    t.hurt(magic(level, caster), 6.0F * power);
                    level.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(),
                            12, 0.3, 0.3, 0.3, 0.2);
                }
            }
            case FIRE -> {
                for (LivingEntity t : foes) {
                    t.setRemainingFireTicks((int) (100 * power * range));
                    t.hurt(magic(level, caster), 2.0F * power);
                    level.sendParticles(ParticleTypes.FLAME, t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(),
                            16, 0.3, 0.4, 0.3, 0.04);
                }
                if (foes.isEmpty()) {
                    level.sendParticles(ParticleTypes.FLAME, pos.x, pos.y, pos.z, 20, 0.4, 0.4, 0.4, 0.05);
                }
            }
            case LIGHTNING -> {
                List<Vec3> strikes = new ArrayList<>();
                for (LivingEntity t : foes) strikes.add(t.position());
                if (strikes.isEmpty() && spell.form() != Glyph.SELF) strikes.add(pos);
                for (Vec3 p : strikes) {
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
                    if (bolt != null) {
                        bolt.moveTo(p.x, p.y, p.z);
                        bolt.setVisualOnly(true);
                        level.addFreshEntity(bolt);
                    }
                }
                for (LivingEntity t : foes) {
                    t.hurt(magic(level, caster), 7.0F * power);
                    t.setRemainingFireTicks(40);
                }
            }
            case PULL -> {
                double radius = 8.0 * range;
                for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                        x -> x != caster && x.isAlive() && !x.isSpectator() && x.position().distanceTo(pos) <= radius)) {
                    Vec3 d = pos.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
                    double len = d.length();
                    if (len < 0.3) continue;
                    Vec3 v = d.normalize().scale(Math.min(2.2, 0.5 + len * 0.18) * power);
                    e.setDeltaMovement(v);
                    e.hurtMarked = true;
                }
                level.sendParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y, pos.z, 40, radius * 0.3, 0.5, radius * 0.3, 0.2);
            }
            case PUSH -> {
                for (LivingEntity t : foes) {
                    Vec3 away = t.position().subtract(caster.position());
                    Vec3 flat = new Vec3(away.x, 0, away.z);
                    if (flat.lengthSqr() < 1.0E-4) flat = caster.getLookAngle();
                    Vec3 v = flat.normalize().scale(1.3 * power);
                    t.setDeltaMovement(t.getDeltaMovement().add(v.x, 0.45, v.z));
                    t.hurtMarked = true;
                    level.sendParticles(ParticleTypes.CLOUD, t.getX(), t.getY() + 0.2, t.getZ(), 8, 0.2, 0.1, 0.2, 0.05);
                }
            }
            case HEAL -> {
                for (LivingEntity t : targets) {
                    t.heal(6.0F * power);
                    level.sendParticles(ParticleTypes.HAPPY_VILLAGER, t.getX(), t.getY() + 1.0, t.getZ(),
                            14, 0.4, 0.6, 0.4, 0.0);
                }
            }
            case FREEZE -> {
                for (LivingEntity t : foes) {
                    t.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, (int) (120 * range), 2));
                    t.setTicksFrozen(t.getTicksRequiredToFreeze() + 40);
                    level.sendParticles(ParticleTypes.SNOWFLAKE, t.getX(), t.getY() + t.getBbHeight() / 2, t.getZ(),
                            20, 0.4, 0.5, 0.4, 0.02);
                }
            }
            case BLINK -> blink(level, caster, spell, pos);
            case EXPLODE -> blast(level, caster, pos, 3.2 * range, 9.0F * power);
            case STARFALL -> starfall(level, caster, spell, pos);
            case BLACK_HOLE -> runBlackHole(level, caster, spell, pos, (int) (80 * range), 0);
            default -> { }
        }
    }

    // =====================================================================
    //  EFEITOS ESPECIAIS
    // =====================================================================
    private static void blink(ServerLevel level, ServerPlayer caster, ParsedSpell spell, Vec3 pos) {
        Vec3 feet;
        if (spell.form() == Glyph.PROJECTILE || spell.form() == Glyph.BEAM) {
            feet = pos;
        } else {
            double dist = 10.0 * spell.range();
            Vec3 eye = caster.getEyePosition();
            Vec3 dir = caster.getLookAngle();
            Vec3 end = eye.add(dir.scale(dist));
            BlockHitResult hit = level.clip(new ClipContext(eye, end,
                    ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, caster));
            Vec3 dest = end;
            boolean floor = false;
            if (hit.getType() != HitResult.Type.MISS) {
                dest = hit.getLocation().subtract(dir.scale(0.6));
                floor = hit.getDirection() == Direction.UP;
            }
            feet = floor ? hit.getLocation() : dest.subtract(0, caster.getEyeHeight(), 0);
        }
        level.sendParticles(ParticleTypes.PORTAL, caster.getX(), caster.getY() + 1.0, caster.getZ(),
                40, 0.4, 0.8, 0.4, 0.3);
        caster.teleportTo(feet.x, feet.y + 0.05, feet.z);
        int tries = 0;
        while (!level.noCollision(caster) && tries++ < 4) {
            caster.teleportTo(caster.getX(), caster.getY() + 1.0, caster.getZ());
        }
        caster.fallDistance = 0.0F;
        level.sendParticles(ParticleTypes.PORTAL, caster.getX(), caster.getY() + 1.0, caster.getZ(),
                40, 0.4, 0.8, 0.4, 0.3);
        level.playSound(null, caster.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 1.2F);
    }

    /** Explosao magica: dano e empurrao em area, sem destruir blocos. */
    private static void blast(ServerLevel level, ServerPlayer caster, Vec3 pos, double radius, float damage) {
        level.sendParticles(ParticleTypes.EXPLOSION, pos.x, pos.y, pos.z, 2, 0.3, 0.3, 0.3, 0.0);
        level.sendParticles(ParticleTypes.FIREWORK, pos.x, pos.y, pos.z, 30, radius * 0.25, radius * 0.25, radius * 0.25, 0.12);
        level.playSound(null, BlockPos.containing(pos), SoundEvents.FIREWORK_ROCKET_LARGE_BLAST,
                SoundSource.PLAYERS, 1.4F, 0.8F);
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                x -> x != caster && x.isAlive() && !x.isSpectator())) {
            double d = e.position().distanceTo(pos);
            if (d > radius) continue;
            float scaled = (float) (damage * (1.0 - d / (radius * 1.3)));
            e.hurt(magic(level, caster), Math.max(1.0F, scaled));
            Vec3 push = e.position().subtract(pos);
            if (push.lengthSqr() > 1.0E-4) {
                push = push.normalize().scale(0.8);
                e.setDeltaMovement(e.getDeltaMovement().add(push.x, 0.35, push.z));
                e.hurtMarked = true;
            }
        }
    }

    /** Chuva de meteoros caindo em volta do ponto de impacto. */
    private static void starfall(ServerLevel level, ServerPlayer caster, ParsedSpell spell, Vec3 pos) {
        int meteors = 5 + (int) (2 * spell.power());
        double spreadRadius = 4.0 * spell.range();
        for (int i = 0; i < meteors; i++) {
            double angle = level.random.nextDouble() * Math.PI * 2.0;
            double dist = level.random.nextDouble() * spreadRadius;
            Vec3 target = new Vec3(pos.x + Math.cos(angle) * dist, pos.y, pos.z + Math.sin(angle) * dist);
            SpellScheduler.later(2 + i * 4, () -> {
                for (int h = 14; h >= 0; h--) {
                    double ox = h * 0.25;
                    level.sendParticles(ParticleTypes.END_ROD, target.x + ox * 0.3, target.y + h, target.z + ox * 0.3,
                            1, 0.05, 0.05, 0.05, 0.0);
                    if (h % 3 == 0) {
                        level.sendParticles(ParticleTypes.FLAME, target.x + ox * 0.3, target.y + h, target.z + ox * 0.3,
                                2, 0.1, 0.1, 0.1, 0.0);
                    }
                }
                blast(level, caster, target, 2.6, 7.0F * spell.power());
            });
        }
        level.playSound(null, BlockPos.containing(pos), SoundEvents.FIRECHARGE_USE, SoundSource.PLAYERS, 1.2F, 0.6F);
    }

    /** Buraco negro: puxa e fere criaturas por alguns segundos e implode no final. */
    private static void runBlackHole(ServerLevel level, ServerPlayer caster, ParsedSpell spell, Vec3 pos,
                                     int duration, int elapsed) {
        double radius = 7.0 * spell.range();
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(pos, pos).inflate(radius),
                x -> x != caster && x.isAlive() && !x.isSpectator() && x.position().distanceTo(pos) <= radius)) {
            Vec3 pull = pos.subtract(e.position().add(0, e.getBbHeight() / 2, 0));
            if (pull.length() > 0.6) {
                e.setDeltaMovement(e.getDeltaMovement().scale(0.55).add(pull.normalize().scale(0.3 + 0.1 * spell.power())));
                e.hurtMarked = true;
            }
            if (elapsed % 10 == 0) {
                e.hurt(magic(level, caster), 2.5F * spell.power());
            }
        }
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, pos.x, pos.y, pos.z, 10, 0.5, 0.5, 0.5, 0.15);
        for (int k = 0; k < 8; k++) {
            double a = elapsed * 0.35 + k * (Math.PI / 4.0);
            double r = radius * 0.55 * (1.0 - (elapsed % 30) / 40.0);
            level.sendParticles(ParticleTypes.PORTAL, pos.x + Math.cos(a) * r, pos.y + 0.2, pos.z + Math.sin(a) * r,
                    2, 0.05, 0.05, 0.05, 0.0);
        }
        if (elapsed == 0) {
            level.playSound(null, BlockPos.containing(pos), SoundEvents.PORTAL_TRIGGER, SoundSource.PLAYERS, 0.7F, 1.6F);
        }
        if (elapsed + 2 < duration) {
            SpellScheduler.later(2, () -> runBlackHole(level, caster, spell, pos, duration, elapsed + 2));
        } else {
            blast(level, caster, pos, 4.5 * spell.range(), 8.0F * spell.power());
        }
    }

    // =====================================================================
    //  UTIL
    // =====================================================================
    private static void dust(ServerLevel level, int rgb, double x, double y, double z, int count, double speed) {
        float r = ((rgb >> 16) & 255) / 255.0F;
        float g = ((rgb >> 8) & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        level.sendParticles(new DustParticleOptions(new Vector3f(r, g, b), 1.1F), x, y, z, count, 0.0, 0.0, 0.0, speed);
    }
}
