package com.example.constellar.spell;

import com.example.constellar.glyph.Glyph;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Magia montada a partir da lista de glifos: 1 forma (primeiro), >=1 efeito, aumentos globais. */
public record ParsedSpell(Glyph form, List<Glyph> effects, int amplify, int extend,
                          boolean multiply, boolean chain, int cost) {

    @Nullable
    public static ParsedSpell parse(List<String> ids) {
        if (ids.isEmpty()) return null;
        Glyph form = null;
        List<Glyph> effects = new ArrayList<>();
        int amplify = 0;
        int extend = 0;
        boolean multiply = false;
        boolean chain = false;
        int cost = 0;

        for (int i = 0; i < ids.size(); i++) {
            Optional<Glyph> found = Glyph.byId(ids.get(i));
            if (found.isEmpty()) return null;
            Glyph glyph = found.get();
            cost += glyph.cost();
            if (glyph.type() == Glyph.Type.FORM) {
                if (i != 0) return null;
                form = glyph;
            } else if (glyph.type() == Glyph.Type.EFFECT) {
                effects.add(glyph);
            } else {
                if (glyph == Glyph.AMPLIFY) amplify++;
                else if (glyph == Glyph.EXTEND) extend++;
                else if (glyph == Glyph.MULTIPLY) multiply = true;
                else if (glyph == Glyph.CHAIN) chain = true;
            }
        }
        if (form == null || effects.isEmpty()) return null;
        return new ParsedSpell(form, List.copyOf(effects), Math.min(amplify, 3), Math.min(extend, 3),
                multiply, chain, cost);
    }

    /** Multiplicador de dano/forca. */
    public float power() {
        return 1.0F + 0.5F * amplify;
    }

    /** Multiplicador de alcance/duracao. */
    public float range() {
        return 1.0F + 0.5F * extend;
    }

    public int color() {
        return effects.get(0).color();
    }
}
