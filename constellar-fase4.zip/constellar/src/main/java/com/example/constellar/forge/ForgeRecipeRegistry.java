package com.example.constellar.forge;

import com.example.constellar.Constellar;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;

public final class ForgeRecipeRegistry {
    public static final ResourceKey<Registry<ForgeRecipe>> KEY =
            ResourceKey.createRegistryKey(ResourceLocation.fromNamespaceAndPath(Constellar.MODID, "forge_recipe"));

    private ForgeRecipeRegistry() {}
}
