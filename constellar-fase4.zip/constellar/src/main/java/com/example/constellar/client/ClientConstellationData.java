package com.example.constellar.client;

import net.minecraft.resources.ResourceLocation;

import java.util.List;

/** Constelacoes descobertas pelo jogador local (enviadas pelo servidor). Sem classes de cliente. */
public final class ClientConstellationData {
    private static volatile List<ResourceLocation> discovered = List.of();

    private ClientConstellationData() {}

    public static List<ResourceLocation> get() {
        return discovered;
    }

    public static void set(List<ResourceLocation> ids) {
        discovered = List.copyOf(ids);
    }
}
