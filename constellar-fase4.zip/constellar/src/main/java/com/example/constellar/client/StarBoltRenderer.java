package com.example.constellar.client;

import com.example.constellar.entity.StarBoltEntity;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;

/** O projetil e desenhado so por particulas (enviadas pelo servidor); o renderizador nao desenha nada. */
public class StarBoltRenderer extends EntityRenderer<StarBoltEntity> {
    private static final ResourceLocation TEXTURE = ResourceLocation.withDefaultNamespace("textures/misc/white.png");

    public StarBoltRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public ResourceLocation getTextureLocation(StarBoltEntity entity) {
        return TEXTURE;
    }
}
