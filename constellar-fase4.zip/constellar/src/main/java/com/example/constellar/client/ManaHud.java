package com.example.constellar.client;

import com.example.constellar.item.SpellScrollItem;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.LayeredDraw;
import net.minecraft.world.entity.player.Player;

/** Barra de mana: aparece quando voce segura um Pergaminho de Magia. */
public class ManaHud implements LayeredDraw.Layer {
    @Override
    public void render(GuiGraphics graphics, DeltaTracker deltaTracker) {
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.options.hideGui) return;
        boolean holding = player.getMainHandItem().getItem() instanceof SpellScrollItem
                || player.getOffhandItem().getItem() instanceof SpellScrollItem;
        if (!holding) return;

        int max = ClientManaData.max();
        if (max <= 0) return;
        int mana = Math.max(0, Math.min(max, ClientManaData.mana()));

        int width = 81;
        int x = graphics.guiWidth() / 2 + 10;
        int y = graphics.guiHeight() - 61;
        graphics.fill(x - 1, y - 1, x + width + 1, y + 6, 0xCC0A0F1E);
        int filled = (int) (width * (mana / (float) max));
        graphics.fill(x, y, x + filled, y + 5, 0xFF3DA5FF);
        graphics.fill(x, y, x + filled, y + 2, 0xFF8FD6FF);
        graphics.drawString(mc.font, mana + " / " + max, x, y - 10, 0x9AE0FF, true);
    }
}
