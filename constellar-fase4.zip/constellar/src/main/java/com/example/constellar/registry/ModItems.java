package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.example.constellar.glyph.Glyph;
import com.example.constellar.item.EnergyReaderItem;
import com.example.constellar.item.GlyphItem;
import com.example.constellar.item.SpellScrollItem;
import com.example.constellar.item.StellarWandItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(Constellar.MODID);

    public static final DeferredItem<Item> STELLAR_CRYSTAL =
            ITEMS.registerSimpleItem("stellar_crystal", new Item.Properties());

    public static final DeferredItem<StellarWandItem> STELLAR_WAND =
            ITEMS.registerItem("stellar_wand", StellarWandItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<EnergyReaderItem> ENERGY_READER =
            ITEMS.registerItem("energy_reader", EnergyReaderItem::new, new Item.Properties().stacksTo(1));

    public static final DeferredItem<SpellScrollItem> SPELL_SCROLL =
            ITEMS.registerItem("spell_scroll", SpellScrollItem::new, new Item.Properties().stacksTo(1));

    /** Um item para cada glifo: glyph_<id>. */
    public static final Map<Glyph, DeferredItem<GlyphItem>> GLYPHS = new EnumMap<>(Glyph.class);

    static {
        for (Glyph glyph : Glyph.values()) {
            GLYPHS.put(glyph, ITEMS.registerItem("glyph_" + glyph.id(),
                    props -> new GlyphItem(props, glyph), new Item.Properties()));
        }
    }

    public static final DeferredItem<BlockItem> TELESCOPE =
            ITEMS.registerSimpleBlockItem("telescope", ModBlocks.TELESCOPE);

    public static final DeferredItem<BlockItem> STELLAR_FORGE =
            ITEMS.registerSimpleBlockItem("stellar_forge", ModBlocks.STELLAR_FORGE);

    public static final DeferredItem<BlockItem> STELLAR_STONE =
            ITEMS.registerSimpleBlockItem("stellar_stone", ModBlocks.STELLAR_STONE);

    public static final DeferredItem<BlockItem> STELLAR_PILLAR =
            ITEMS.registerSimpleBlockItem("stellar_pillar", ModBlocks.STELLAR_PILLAR);

    public static final DeferredItem<BlockItem> STELLAR_LENS =
            ITEMS.registerSimpleBlockItem("stellar_lens", ModBlocks.STELLAR_LENS);

    public static final DeferredItem<BlockItem> VOID_CRYSTAL =
            ITEMS.registerSimpleBlockItem("void_crystal", ModBlocks.VOID_CRYSTAL);

    public static final DeferredItem<BlockItem> STELLAR_BATTERY =
            ITEMS.registerSimpleBlockItem("stellar_battery", ModBlocks.STELLAR_BATTERY);

    private ModItems() {}
}
