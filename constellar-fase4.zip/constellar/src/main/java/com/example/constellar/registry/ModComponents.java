package com.example.constellar.registry;

import com.example.constellar.Constellar;
import com.mojang.serialization.Codec;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.network.codec.ByteBufCodecs;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.List;

public final class ModComponents {
    public static final DeferredRegister.DataComponents COMPONENTS =
            DeferredRegister.createDataComponents(Constellar.MODID);

    /** Lista de ids de glifos gravados num Pergaminho de Magia. */
    public static final DeferredHolder<DataComponentType<?>, DataComponentType<List<String>>> SPELL =
            COMPONENTS.registerComponentType("spell", builder -> builder
                    .persistent(Codec.STRING.listOf())
                    .networkSynchronized(ByteBufCodecs.STRING_UTF8.apply(ByteBufCodecs.list())));

    private ModComponents() {}
}
