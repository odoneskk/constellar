package com.example.constellar.multiblock;

import com.example.constellar.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

/**
 * Forja Estelar (multibloco 3x3):
 *  - centro: Forja Estelar; em cima dela: Cristal do Void
 *  - nas 4 pontas do 3x3 (laterais): Pedra Estelar
 *  - nos 4 cantos: torre de 2 Pilares Estelares com uma Lente Estelar no topo
 */
public final class ForgeStructure {
    private ForgeStructure() {}

    public record Mismatch(BlockPos pos, Block expected) {}

    public static List<Mismatch> findAllMismatches(Level level, BlockPos forge) {
        List<Mismatch> missing = new ArrayList<>();
        check(level, forge.above(), ModBlocks.VOID_CRYSTAL.get(), missing);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos base = forge.offset(dx, 0, dz);
                boolean corner = dx != 0 && dz != 0;
                if (corner) {
                    check(level, base, ModBlocks.STELLAR_PILLAR.get(), missing);
                    check(level, base.above(), ModBlocks.STELLAR_PILLAR.get(), missing);
                    check(level, base.above(2), ModBlocks.STELLAR_LENS.get(), missing);
                } else {
                    check(level, base, ModBlocks.STELLAR_STONE.get(), missing);
                }
            }
        }
        return missing;
    }

    @Nullable
    public static Mismatch findMismatch(Level level, BlockPos forge) {
        List<Mismatch> all = findAllMismatches(level, forge);
        return all.isEmpty() ? null : all.get(0);
    }

    private static void check(Level level, BlockPos pos, Block expected, List<Mismatch> out) {
        if (!level.getBlockState(pos).is(expected)) {
            out.add(new Mismatch(pos, expected));
        }
    }

    /** Quantas torres tem ceu aberto acima da lente (0 a 4). */
    public static int countTowersWithSky(Level level, BlockPos forge) {
        int count = 0;
        for (int dx = -1; dx <= 1; dx += 2) {
            for (int dz = -1; dz <= 1; dz += 2) {
                if (level.canSeeSky(forge.offset(dx, 3, dz))) count++;
            }
        }
        return count;
    }
}
