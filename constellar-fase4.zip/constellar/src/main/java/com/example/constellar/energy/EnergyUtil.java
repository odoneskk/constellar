package com.example.constellar.energy;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.level.Level;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.energy.IEnergyStorage;

public final class EnergyUtil {
    private EnergyUtil() {}

    /** Empurra FE para os blocos vizinhos que aceitem (cabos, baterias, maquinas...). */
    public static void pushToNeighbors(Level level, BlockPos pos, FEStorage storage, int rate) {
        if (storage.getEnergyStored() <= 0) return;
        for (Direction dir : Direction.values()) {
            IEnergyStorage target = level.getCapability(Capabilities.EnergyStorage.BLOCK, pos.relative(dir), dir.getOpposite());
            if (target == null || !target.canReceive()) continue;
            int offered = storage.extractEnergy(rate, true);
            if (offered <= 0) break;
            int accepted = target.receiveEnergy(offered, false);
            storage.extractEnergy(accepted, false);
            if (storage.getEnergyStored() <= 0) break;
        }
    }
}
