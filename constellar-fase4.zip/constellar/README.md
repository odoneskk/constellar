# Constellar (nome provisório) — fase 4

Mod para Minecraft 1.21.1 / NeoForge 21.1.x. Livro de guia: precisa do **Modonomicon 1.21.1** instalado.

## Progressão
1. **Telescópio** (bloco 3D): leia as estrelas à noite; as constelações aparecem desenhadas no céu.
2. **Forja Estelar** (multibloco 3x3): forja no centro com o Cristal do Void em cima, Pedra Estelar nos 4 lados,
   torres de 2 Pilares com Lente nos 4 cantos. Ative com a Varinha Estelar (nuvens azuis mostram o que falta).
3. **Magias**: coloque 1 papel e glifos na forja (forma primeiro, depois efeitos e aumentos) e clique com a varinha
   para criar um Pergaminho de Magia. Botão direito lança (gasta mana).

## Magias (19 glifos)
- Formas: Projétil, Raio, Si Mesmo, Área
- Efeitos: Dano, Chama, Relâmpago, Atração, Repulsão, Cura, Salto Dimensional, Congelar, Explosão, Chuva de Estrelas, Buraco Negro
- Aumentos: Amplificar, Estender, Multiplicar, Corrente
- Mana máxima: 100 + 20 por constelação; recarga 4/s (10/s à noite sob o céu aberto)

## Compilar
Veja as instruções do GitHub Actions. O .jar sai em `build/libs/constellar-0.4.0.jar`.
